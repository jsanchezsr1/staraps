import { PrismaClient } from "@prisma/client";

declare global {
  var __platformPrisma__: PrismaClient | undefined;
}

export const prisma = global.__platformPrisma__ ?? new PrismaClient({ log: ["warn", "error"] });

if (process.env.NODE_ENV !== "production") global.__platformPrisma__ = prisma;
