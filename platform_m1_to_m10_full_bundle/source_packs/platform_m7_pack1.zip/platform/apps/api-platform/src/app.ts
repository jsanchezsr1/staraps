import "dotenv/config";
import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { registerAuthRoutes } from "./modules/auth/routes";
import { registerOrganizationRoutes } from "./modules/organizations/routes";
import { registerProjectRoutes } from "./modules/projects/routes";
import { registerVersionRoutes } from "./modules/versions/routes";
import { registerJobRoutes } from "./modules/jobs/routes";
import { registerPlatformRoutes } from "./modules/platform/routes";
import { registerMarketplaceRoutes } from "./modules/marketplace/routes";
import { registerOpsRoutes } from "./modules/ops/routes";
import { registerRuntimeRoutes } from "./modules/runtime/routes";
import { registerBillingRoutes } from "./modules/billing/routes";
import { registerWorkspaceRoutes } from "./modules/workspace/routes";
import { registerDiagnosticsRoutes } from "./modules/diagnostics/routes";
import { registerPluginMarketplaceRoutes } from "./modules/plugins/routes";
import { registerAIRoutes } from "./modules/ai/routes";
import { registerDeveloperRoutes } from "./modules/developer/routes";
import { registerCollaborationRoutes } from "./modules/collaboration/routes";
import { registerCopilotRoutes } from "./modules/copilot/routes";
import { registerEnterpriseRoutes } from "./modules/enterprise/routes";
import { registerMonetizationRoutes } from "./modules/monetization/routes";
import { registerGlobalScaleRoutes } from "./modules/global-scale/routes";
import { registerAutonomousBuilderRoutes } from "./modules/autonomous-builder/routes";
import { errorHandler } from "./middleware/errorHandler";
import { notFoundHandler } from "./middleware/notFound";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: true, credentials: true }));
  app.use(cookieParser());
  app.use(express.json({ limit: "1mb" }));
  app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));

  app.get("/api/health", (_req, res) => res.json({ ok: true, service: "api-platform" }));
  app.get("/api/readiness", (_req, res) => res.json({ ok: true, readiness: "ready" }));

  registerAuthRoutes(app);
  registerOrganizationRoutes(app);
  registerProjectRoutes(app);
  registerVersionRoutes(app);
  registerJobRoutes(app);
  registerPlatformRoutes(app);
  registerMarketplaceRoutes(app);
  registerOpsRoutes(app);
  registerRuntimeRoutes(app);
  registerBillingRoutes(app);
  registerWorkspaceRoutes(app);
  registerDiagnosticsRoutes(app);
  registerPluginMarketplaceRoutes(app);
  registerAIRoutes(app);
  registerDeveloperRoutes(app);
  registerCollaborationRoutes(app);
  registerCopilotRoutes(app);
  registerEnterpriseRoutes(app);
  registerMonetizationRoutes(app);
  registerGlobalScaleRoutes(app);
  registerAutonomousBuilderRoutes(app);

  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}
