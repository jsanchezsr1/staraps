export type PlatformPlugin = {
  key: string;
  name: string;
  version: string;
  type: "generator" | "deployment" | "integration" | "ui";
  description: string;
  enabledByDefault?: boolean;
};

export const builtInPlugins: PlatformPlugin[] = [
  {
    key: "generator.core-crud",
    name: "Core CRUD Generator",
    version: "1.0.0",
    type: "generator",
    description: "Base Prisma, backend, frontend, admin, and mobile generation",
    enabledByDefault: true
  },
  {
    key: "deployment.local-docker",
    name: "Local Docker Deployment",
    version: "1.0.0",
    type: "deployment",
    description: "Docker compose preview/deployment scaffold",
    enabledByDefault: true
  },
  {
    key: "integration.ai-spec-draft",
    name: "AI Spec Draft",
    version: "1.0.0",
    type: "integration",
    description: "Natural language to App Spec draft scaffold",
    enabledByDefault: false
  }
];

export function listPlugins(): PlatformPlugin[] {
  return builtInPlugins;
}

export function getPluginByKey(key: string): PlatformPlugin | undefined {
  return builtInPlugins.find((plugin) => plugin.key === key);
}
