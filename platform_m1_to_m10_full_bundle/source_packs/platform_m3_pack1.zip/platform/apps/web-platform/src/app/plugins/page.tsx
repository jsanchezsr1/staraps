export default function PluginsPage() {
  return (
    <main>
      <h1>Plugin Marketplace</h1>
      <p>Plugin listing and installation UI scaffold for Milestone 3.</p>
    </main>
  );
}
