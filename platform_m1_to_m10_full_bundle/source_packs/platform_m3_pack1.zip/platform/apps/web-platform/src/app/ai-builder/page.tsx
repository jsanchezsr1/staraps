export default function AiBuilderPage() {
  return (
    <main>
      <h1>AI App Builder</h1>
      <p>Prompt-to-spec drafting UI scaffold for Milestone 3.</p>
    </main>
  );
}
