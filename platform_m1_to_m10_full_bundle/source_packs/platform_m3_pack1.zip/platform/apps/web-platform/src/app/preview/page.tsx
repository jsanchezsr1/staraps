export default function PreviewPage() {
  return (
    <main>
      <h1>Preview Jobs</h1>
      <p>Live preview management UI scaffold for Milestone 3.</p>
    </main>
  );
}
