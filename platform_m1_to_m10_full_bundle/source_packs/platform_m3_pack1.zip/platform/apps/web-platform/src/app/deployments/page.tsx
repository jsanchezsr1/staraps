export default function DeploymentsPage() {
  return (
    <main>
      <h1>Deployments</h1>
      <p>Deployment jobs management UI scaffold for Milestone 3.</p>
    </main>
  );
}
