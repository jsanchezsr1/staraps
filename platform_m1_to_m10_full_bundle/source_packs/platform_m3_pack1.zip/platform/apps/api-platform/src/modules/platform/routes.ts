import { randomUUID } from "crypto";
import { Express } from "express";
import {
  pluginInstallationsRepository,
  platformJobsRepository,
  projectVersionsRepository,
  projectsRepository,
  OrganizationRole
} from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import { requireProjectAccess } from "../../middleware/requireProjectAccess";
import { requireOrgRole } from "../../middleware/requireOrgRole";
import { validateBody } from "../../validators/common";
import {
  aiSpecDraftSchema,
  createDeploymentJobSchema,
  createPreviewJobSchema
} from "../../validators/platform-jobs.dto";
import { enqueueDeploymentJob, enqueuePreviewJob } from "../../services/platformQueue";
import { draftSpecFromPrompt } from "../../services/aiSpecDraft";
import { writeAuditLog } from "../../utils/audit";
import { listPlugins } from "@platform/plugins";

export function registerPlatformRoutes(app: Express): void {
  app.get("/api/platform/plugins", requireAuth, async (_req, res) => {
    res.json(listPlugins());
  });

  app.get("/api/projects/:id/platform-jobs", requireAuth, requireProjectAccess([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN,
    OrganizationRole.DEVELOPER,
    OrganizationRole.VIEWER
  ]), async (req, res) => {
    const jobs = await platformJobsRepository.listByProject(req.params.id);
    res.json(jobs);
  });

  app.post("/api/projects/:id/preview", requireAuth, requireProjectAccess([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN,
    OrganizationRole.DEVELOPER
  ]), validateBody(createPreviewJobSchema), async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const project = await projectsRepository.findById(req.params.id);
    const version = await projectVersionsRepository.findById(req.body.versionId);

    if (!project || !version) {
      res.status(404).json({ message: "Project or version not found" });
      return;
    }

    const job = await platformJobsRepository.create({
      id: randomUUID(),
      projectId: req.params.id,
      projectVersionId: req.body.versionId,
      requestedByUserId: req.user.id,
      type: "PREVIEW",
      status: "QUEUED",
      target: "local-preview"
    });

    await enqueuePreviewJob({
      platformJobId: job.id,
      projectId: req.params.id,
      versionId: req.body.versionId,
      requestedByUserId: req.user.id,
      type: "PREVIEW",
      target: "local-preview"
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      projectId: req.params.id,
      action: "platform.preview.enqueue",
      entityType: "PlatformJob",
      entityId: job.id
    });

    res.status(202).json(job);
  });

  app.post("/api/projects/:id/deploy", requireAuth, requireProjectAccess([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN,
    OrganizationRole.DEVELOPER
  ]), validateBody(createDeploymentJobSchema), async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const project = await projectsRepository.findById(req.params.id);
    const version = await projectVersionsRepository.findById(req.body.versionId);

    if (!project || !version) {
      res.status(404).json({ message: "Project or version not found" });
      return;
    }

    const job = await platformJobsRepository.create({
      id: randomUUID(),
      projectId: req.params.id,
      projectVersionId: req.body.versionId,
      requestedByUserId: req.user.id,
      type: "DEPLOYMENT",
      status: "QUEUED",
      target: req.body.target
    });

    await enqueueDeploymentJob({
      platformJobId: job.id,
      projectId: req.params.id,
      versionId: req.body.versionId,
      requestedByUserId: req.user.id,
      type: "DEPLOYMENT",
      target: req.body.target
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      projectId: req.params.id,
      action: "platform.deployment.enqueue",
      entityType: "PlatformJob",
      entityId: job.id,
      metadataJson: { target: req.body.target }
    });

    res.status(202).json(job);
  });

  app.post("/api/platform/ai-spec-draft", requireAuth, validateBody(aiSpecDraftSchema), async (req, res) => {
    const draft = draftSpecFromPrompt({
      prompt: req.body.prompt,
      nameHint: req.body.nameHint
    });

    await writeAuditLog({
      actorUserId: req.user?.id,
      action: "platform.ai_spec_draft.generate",
      entityType: "AppSpecDraft"
    });

    res.json(draft);
  });

  app.post("/api/organizations/:id/plugins/install", requireAuth, requireOrgRole([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN
  ]), async (req, res) => {
    const pluginKey = String(req.body?.pluginKey || "");
    if (!pluginKey) {
      res.status(400).json({ message: "pluginKey is required" });
      return;
    }

    const installation = await pluginInstallationsRepository.install({
      id: randomUUID(),
      organizationId: req.params.id,
      pluginKey,
      enabled: true,
      configJson: req.body?.configJson || null
    });

    await writeAuditLog({
      actorUserId: req.user?.id,
      organizationId: req.params.id,
      action: "platform.plugin.install",
      entityType: "PluginInstallation",
      entityId: installation.id,
      metadataJson: { pluginKey }
    });

    res.status(201).json(installation);
  });
}
