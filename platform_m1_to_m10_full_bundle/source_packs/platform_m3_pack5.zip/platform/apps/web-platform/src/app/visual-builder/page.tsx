export default function VisualBuilderPage() {
  return (
    <main>
      <h1>Visual App Builder</h1>
      <p>Design models, pages, APIs, and workflows visually.</p>
      <ul>
        <li>Model canvas</li>
        <li>Field editor</li>
        <li>Page editor</li>
        <li>Workflow panel</li>
      </ul>
    </main>
  );
}
