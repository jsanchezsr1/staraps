import { randomUUID } from "crypto";
import { builderStateRepository, projectVersionsRepository, projectsRepository } from "@platform/database";

export async function saveBuilderState(input: {
  projectId: string;
  projectVersionId?: string;
  selectedNodeId?: string | null;
  layoutJson: unknown;
}) {
  return builderStateRepository.upsert({
    id: randomUUID(),
    projectId: input.projectId,
    projectVersionId: input.projectVersionId || null,
    layoutJson: input.layoutJson,
    selectedNodeId: input.selectedNodeId || null
  });
}

export async function applySpecPatch(input: {
  projectId: string;
  versionId: string;
  patch: Record<string, unknown>;
  createdByUserId: string;
}) {
  const version = await projectVersionsRepository.findById(input.versionId);
  if (!version) throw new Error("Project version not found");

  const mergedSpec = {
    ...(version.appSpecJson as Record<string, unknown>),
    ...input.patch
  };

  const versions = await projectVersionsRepository.listByProject(input.projectId);
  const nextVersionNumber = versions.length > 0 ? versions[0].versionNumber + 1 : 1;

  const newVersion = await projectVersionsRepository.create({
    projectId: input.projectId,
    versionNumber: nextVersionNumber,
    appSpecJson: mergedSpec,
    specSchemaVersion: String((mergedSpec as any)?.meta?.version || version.specSchemaVersion),
    createdByUserId: input.createdByUserId,
    notes: `Visual builder patch from version ${version.versionNumber}`
  });

  await projectsRepository.update(input.projectId, { latestVersionId: newVersion.id });
  return newVersion;
}
