import { z } from "zod";

export const builderStateSchema = z.object({
  projectVersionId: z.string().optional(),
  selectedNodeId: z.string().nullable().optional(),
  layoutJson: z.record(z.any())
});

export const specPatchSchema = z.object({
  patch: z.record(z.any())
});

export const previewRefreshSchema = z.object({
  versionId: z.string().min(1),
  target: z.string().default("local-docker")
});
