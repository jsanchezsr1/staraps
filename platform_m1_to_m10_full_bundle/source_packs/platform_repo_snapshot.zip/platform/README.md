# Platform

Milestone 1 monorepo scaffold for a Base44-style competitor.

## Included
- `apps/web-platform` - Next.js control plane
- `apps/api-platform` - Express API
- `apps/worker` - BullMQ worker
- `packages/database` - Prisma schema and repositories
- `packages/app-spec` - App Spec zod schema/types
- `packages/auth` - auth helpers
- `packages/shared` - logger/env/errors
- `packages/templates` - template registry
- `packages/generator` - generation pipeline scaffold

## Quick start
1. Copy `.env.example` to `.env`
2. Start infra:
   - `docker compose up -d`
3. Install deps:
   - `pnpm install`
4. Generate Prisma client:
   - `pnpm --filter @platform/database prisma:generate`
5. Run services:
   - `pnpm dev`

## Important
This is a runnable scaffold, not a production-complete system.
Some parts are placeholders:
- artifact zipping
- strong JWT verification
- full authorization matrix
- full template rendering
