import { NextFunction, Request, Response } from "express";
import { verifyJwt } from "@platform/auth";
import { env } from "@platform/shared";

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }

  try {
    const token = authHeader.slice("Bearer ".length).trim();
    const payload = verifyJwt(token, env("JWT_SECRET", "change_me"));
    req.user = {
      id: String(payload.sub),
      email: typeof payload.email === "string" ? payload.email : undefined
    };
    next();
  } catch {
    res.status(401).json({ message: "Invalid token" });
  }
}
