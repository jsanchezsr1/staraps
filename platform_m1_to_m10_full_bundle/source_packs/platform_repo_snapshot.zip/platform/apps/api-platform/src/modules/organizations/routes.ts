import { Express } from "express";
import { organizationsRepository, prisma, OrganizationRole } from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import { slugify } from "../../utils/slugify";

export function registerOrganizationRoutes(app: Express): void {
  app.post("/api/organizations", requireAuth, async (req, res) => {
    try {
      const { name, slug } = req.body as { name?: string; slug?: string };

      if (!req.user?.id) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      if (!name) {
        res.status(400).json({ message: "name is required" });
        return;
      }

      const organization = await organizationsRepository.createWithOwner({
        name,
        slug: slug || slugify(name),
        createdByUserId: req.user.id
      });

      res.status(201).json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to create organization", error: String(error) });
    }
  });

  app.get("/api/organizations", requireAuth, async (req, res) => {
    try {
      if (!req.user?.id) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      const organizations = await organizationsRepository.listForUser(req.user.id);
      res.json(organizations);
    } catch (error) {
      res.status(500).json({ message: "Failed to list organizations", error: String(error) });
    }
  });

  app.post("/api/organizations/:id/invite", requireAuth, async (req, res) => {
    try {
      const { email, role } = req.body as { email?: string; role?: OrganizationRole };
      const organizationId = req.params.id;

      if (!email || !role) {
        res.status(400).json({ message: "email and role are required" });
        return;
      }

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        res.status(404).json({ message: "User not found" });
        return;
      }

      const membership = await prisma.organizationMembership.upsert({
        where: {
          organizationId_userId: {
            organizationId,
            userId: user.id
          }
        },
        update: { role },
        create: {
          organizationId,
          userId: user.id,
          role
        }
      });

      res.status(201).json(membership);
    } catch (error) {
      res.status(500).json({ message: "Failed to invite member", error: String(error) });
    }
  });

  app.patch("/api/organizations/:id/members/:memberId/role", requireAuth, async (req, res) => {
    try {
      const { role } = req.body as { role?: OrganizationRole };
      const organizationId = req.params.id;
      const memberId = req.params.memberId;

      if (!role) {
        res.status(400).json({ message: "role is required" });
        return;
      }

      const membership = await prisma.organizationMembership.update({
        where: {
          organizationId_userId: {
            organizationId,
            userId: memberId
          }
        },
        data: { role }
      });

      res.json(membership);
    } catch (error) {
      res.status(500).json({ message: "Failed to update member role", error: String(error) });
    }
  });
}
