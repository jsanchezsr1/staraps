import { Express } from "express";
import { hashPassword, signJwt, verifyPassword } from "@platform/auth";
import { env } from "@platform/shared";
import { usersRepository } from "@platform/database";

export function registerAuthRoutes(app: Express): void {
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, name } = req.body as {
        email?: string;
        password?: string;
        name?: string;
      };

      if (!email || !password) {
        res.status(400).json({ message: "email and password are required" });
        return;
      }

      const existingUser = await usersRepository.findByEmail(email);
      if (existingUser) {
        res.status(409).json({ message: "Email already registered" });
        return;
      }

      const passwordHash = await hashPassword(password);
      const user = await usersRepository.create({ email, passwordHash, name });

      const token = signJwt(
        {
          sub: user.id,
          email: user.email
        },
        env("JWT_SECRET", "change_me")
      );

      res.status(201).json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name
        },
        token
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to register", error: String(error) });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body as {
        email?: string;
        password?: string;
      };

      if (!email || !password) {
        res.status(400).json({ message: "email and password are required" });
        return;
      }

      const user = await usersRepository.findByEmail(email);
      if (!user) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const valid = await verifyPassword(password, user.passwordHash);
      if (!valid) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const token = signJwt(
        {
          sub: user.id,
          email: user.email
        },
        env("JWT_SECRET", "change_me")
      );

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name
        },
        token
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to login", error: String(error) });
    }
  });

  app.get("/api/auth/me", requireAuthShim, async (req, res) => {
    res.json({ user: req.user });
  });
}

function requireAuthShim(req: any, res: any, next: any) {
  next();
}
