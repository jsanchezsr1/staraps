# Healthcheck suggestions

## API
Use `/api/health` for liveness and `/api/readiness` for readiness.

## Worker
Use process supervisor restart policy and queue lag metrics.

## Web
Use `/` or a custom `/healthz` route if you add one.

## Operational follow-up
- add structured logs
- add metrics exporter
- add trace correlation IDs
- add artifact storage off local disk
