import fs from "fs-extra";
import path from "path";
import { prisma } from "@platform/database";

export async function cleanupOldArtifacts(options?: {
  olderThanDays?: number;
}) {
  const olderThanDays = options?.olderThanDays ?? 30;
  const cutoff = new Date(Date.now() - olderThanDays * 24 * 60 * 60 * 1000);

  const artifacts = await prisma.generatedArtifact.findMany({
    where: {
      createdAt: { lt: cutoff }
    }
  });

  let deleted = 0;

  for (const artifact of artifacts) {
    const absolutePath = path.resolve(artifact.filePath);
    if (await fs.pathExists(absolutePath)) {
      await fs.remove(absolutePath);
    }

    await prisma.generatedArtifact.delete({
      where: { id: artifact.id }
    });

    deleted += 1;
  }

  return { deleted };
}
