import { organizationInvitesRepository, refreshTokensRepository } from "@platform/database";

export async function cleanupSecurityState() {
  await refreshTokensRepository.deleteExpired();
  await organizationInvitesRepository.expireOld();
  return { ok: true };
}
