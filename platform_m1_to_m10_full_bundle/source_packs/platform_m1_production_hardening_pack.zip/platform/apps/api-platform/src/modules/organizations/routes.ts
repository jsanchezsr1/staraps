import { Express } from "express";
import { organizationsRepository, prisma, OrganizationRole } from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import { requireOrgRole } from "../../middleware/requireOrgRole";
import { validateBody } from "../../validators/common";
import { createOrganizationSchema, inviteMemberSchema, updateMemberRoleSchema } from "../../validators/organizations.dto";
import { slugify } from "@platform/shared";
import { createOrganizationInvite, acceptOrganizationInvite } from "../../services/invitations";
import { writeAuditLog } from "../../utils/audit";

export function registerOrganizationRoutes(app: Express): void {
  app.post("/api/organizations", requireAuth, validateBody(createOrganizationSchema), async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const { name, slug } = req.body;
    const organization = await organizationsRepository.createWithOwner({
      name,
      slug: slug || slugify(name),
      createdByUserId: req.user.id
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      organizationId: organization.id,
      action: "organization.create",
      entityType: "Organization",
      entityId: organization.id
    });

    res.status(201).json(organization);
  });

  app.get("/api/organizations", requireAuth, async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const organizations = await organizationsRepository.listForUser(req.user.id);
    res.json(organizations);
  });

  app.post("/api/organizations/:id/invite", requireAuth, requireOrgRole([OrganizationRole.OWNER, OrganizationRole.ADMIN]), validateBody(inviteMemberSchema), async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const { email, role } = req.body;
    const created = await createOrganizationInvite({
      organizationId: req.params.id,
      email,
      role,
      createdByUserId: req.user.id
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      organizationId: req.params.id,
      action: "organization.invite.create",
      entityType: "OrganizationInvite",
      entityId: created.invite.id,
      metadataJson: { email, role }
    });

    res.status(201).json({
      inviteId: created.invite.id,
      inviteToken: created.rawToken
    });
  });

  app.post("/api/organizations/accept-invite", requireAuth, async (req, res) => {
    if (!req.user?.id || !req.user.email) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const rawToken = req.body?.inviteToken as string | undefined;
    if (!rawToken) {
      res.status(400).json({ message: "inviteToken is required" });
      return;
    }

    const invite = await acceptOrganizationInvite({
      rawToken,
      userId: req.user.id,
      userEmail: req.user.email
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      organizationId: invite.organizationId,
      action: "organization.invite.accept",
      entityType: "OrganizationInvite",
      entityId: invite.id
    });

    const membership = await prisma.organizationMembership.findUnique({
      where: {
        organizationId_userId: {
          organizationId: invite.organizationId,
          userId: req.user.id
        }
      }
    });

    res.json({ ok: true, membership });
  });

  app.patch("/api/organizations/:id/members/:memberId/role", requireAuth, requireOrgRole([OrganizationRole.OWNER, OrganizationRole.ADMIN]), validateBody(updateMemberRoleSchema), async (req, res) => {
    const membership = await prisma.organizationMembership.update({
      where: {
        organizationId_userId: {
          organizationId: req.params.id,
          userId: req.params.memberId
        }
      },
      data: {
        role: req.body.role
      }
    });

    await writeAuditLog({
      actorUserId: req.user?.id,
      organizationId: req.params.id,
      action: "organization.membership.role.update",
      entityType: "OrganizationMembership",
      entityId: membership.id,
      metadataJson: { role: req.body.role }
    });

    res.json(membership);
  });
}
