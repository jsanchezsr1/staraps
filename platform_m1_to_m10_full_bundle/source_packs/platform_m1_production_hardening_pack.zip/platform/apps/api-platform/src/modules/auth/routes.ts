import { Express } from "express";
import { hashPassword, signJwt, verifyPassword } from "@platform/auth";
import { env } from "@platform/shared";
import { usersRepository } from "@platform/database";
import { validateBody } from "../../validators/common";
import { loginSchema, registerSchema } from "../../validators/auth.dto";
import { requireAuth } from "../../middleware/requireAuth";
import { issueRefreshToken, rotateRefreshToken, sessionCookies } from "../../services/authTokens";
import { writeAuditLog } from "../../utils/audit";

export function registerAuthRoutes(app: Express): void {
  app.post("/api/auth/register", validateBody(registerSchema), async (req, res) => {
    const { email, password, name } = req.body;
    const existingUser = await usersRepository.findByEmail(email);
    if (existingUser) {
      res.status(409).json({ message: "Email already registered" });
      return;
    }

    const user = await usersRepository.create({
      email,
      passwordHash: await hashPassword(password),
      name
    });

    const accessToken = signJwt({ sub: user.id, email: user.email }, env("JWT_SECRET"));
    const refreshToken = await issueRefreshToken({ userId: user.id });
    const cookies = sessionCookies({
      accessToken,
      refreshToken,
      isProduction: env("NODE_ENV", "development") === "production",
      cookieDomain: process.env.COOKIE_DOMAIN
    });

    res.cookie(cookies.access.name, cookies.access.value, cookies.access.options);
    res.cookie(cookies.refresh.name, cookies.refresh.value, cookies.refresh.options);
    res.cookie(cookies.csrf.name, cookies.csrf.value, cookies.csrf.options);

    await writeAuditLog({
      actorUserId: user.id,
      action: "auth.register",
      entityType: "User",
      entityId: user.id
    });

    res.status(201).json({
      user: { id: user.id, email: user.email, name: user.name },
      token: accessToken,
      csrfToken: cookies.csrfToken
    });
  });

  app.post("/api/auth/login", validateBody(loginSchema), async (req, res) => {
    const { email, password } = req.body;
    const user = await usersRepository.findByEmail(email);

    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      res.status(401).json({ message: "Invalid credentials" });
      return;
    }

    const accessToken = signJwt({ sub: user.id, email: user.email }, env("JWT_SECRET"));
    const refreshToken = await issueRefreshToken({ userId: user.id });
    const cookies = sessionCookies({
      accessToken,
      refreshToken,
      isProduction: env("NODE_ENV", "development") === "production",
      cookieDomain: process.env.COOKIE_DOMAIN
    });

    res.cookie(cookies.access.name, cookies.access.value, cookies.access.options);
    res.cookie(cookies.refresh.name, cookies.refresh.value, cookies.refresh.options);
    res.cookie(cookies.csrf.name, cookies.csrf.value, cookies.csrf.options);

    await writeAuditLog({
      actorUserId: user.id,
      action: "auth.login",
      entityType: "User",
      entityId: user.id
    });

    res.json({
      user: { id: user.id, email: user.email, name: user.name },
      token: accessToken,
      csrfToken: cookies.csrfToken
    });
  });

  app.post("/api/auth/refresh", requireAuth, async (req, res) => {
    const rawRefreshToken = (req as any).cookies?.platform_refresh;
    if (!rawRefreshToken || !req.user?.id || !req.user.email) {
      res.status(401).json({ message: "Missing refresh session" });
      return;
    }

    const nextRefreshToken = await rotateRefreshToken({
      currentRawToken: rawRefreshToken,
      userId: req.user.id
    });

    const accessToken = signJwt({ sub: req.user.id, email: req.user.email }, env("JWT_SECRET"));
    const cookies = sessionCookies({
      accessToken,
      refreshToken: nextRefreshToken,
      isProduction: env("NODE_ENV", "development") === "production",
      cookieDomain: process.env.COOKIE_DOMAIN
    });

    res.cookie(cookies.access.name, cookies.access.value, cookies.access.options);
    res.cookie(cookies.refresh.name, cookies.refresh.value, cookies.refresh.options);
    res.cookie(cookies.csrf.name, cookies.csrf.value, cookies.csrf.options);

    res.json({ ok: true, token: accessToken, csrfToken: cookies.csrfToken });
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    for (const name of ["platform_token", "platform_refresh", "platform_csrf"]) {
      res.clearCookie(name, { path: "/", httpOnly: name !== "platform_csrf", secure: env("NODE_ENV", "development") === "production", sameSite: "lax" });
    }

    await writeAuditLog({
      actorUserId: req.user?.id,
      action: "auth.logout",
      entityType: "User",
      entityId: req.user?.id
    });

    res.json({ ok: true });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });
}
