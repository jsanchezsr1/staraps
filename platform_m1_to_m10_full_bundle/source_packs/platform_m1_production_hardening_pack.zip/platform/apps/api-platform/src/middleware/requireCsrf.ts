import { NextFunction, Request, Response } from "express";
import { isSafeMethod } from "@platform/shared/http";

export function requireCsrf(req: Request, res: Response, next: NextFunction): void {
  if (isSafeMethod(req.method)) {
    next();
    return;
  }

  const cookieToken = (req as any).cookies?.platform_csrf;
  const headerToken = req.headers["x-csrf-token"];

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    res.status(403).json({ message: "Invalid CSRF token" });
    return;
  }

  next();
}
