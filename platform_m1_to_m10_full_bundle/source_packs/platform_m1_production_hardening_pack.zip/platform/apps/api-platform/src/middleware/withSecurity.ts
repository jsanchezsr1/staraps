import { RequestHandler } from "express";
import { requireAuth } from "./requireAuth";
import { requireCsrf } from "./requireCsrf";

export const withMutatingSecurity: RequestHandler[] = [requireAuth, requireCsrf];
