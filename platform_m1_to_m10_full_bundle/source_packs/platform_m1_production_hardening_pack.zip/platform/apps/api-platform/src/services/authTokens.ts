import { randomUUID } from "crypto";
import { buildCookieOptions } from "@platform/auth";
import { csrfCookieOptions, generateCsrfToken, generateRefreshToken } from "@platform/auth/session";
import { refreshTokensRepository } from "@platform/database";
import { expiresInDays, sha256 } from "@platform/shared/security";

export async function issueRefreshToken(input: {
  userId: string;
}) {
  const rawToken = generateRefreshToken();
  const tokenHash = sha256(rawToken);

  await refreshTokensRepository.create({
    id: randomUUID(),
    userId: input.userId,
    tokenHash,
    expiresAt: expiresInDays(30)
  });

  return rawToken;
}

export async function rotateRefreshToken(input: {
  currentRawToken: string;
  userId: string;
}) {
  const currentHash = sha256(input.currentRawToken);
  const existing = await refreshTokensRepository.findByTokenHash(currentHash);

  if (!existing || existing.userId !== input.userId || existing.revokedAt || existing.expiresAt < new Date()) {
    throw new Error("Invalid refresh token");
  }

  await refreshTokensRepository.revoke(currentHash);
  return issueRefreshToken({ userId: input.userId });
}

export function sessionCookies(input: {
  accessToken: string;
  refreshToken: string;
  isProduction: boolean;
  cookieDomain?: string;
}) {
  const csrfToken = generateCsrfToken();

  return {
    access: {
      name: "platform_token",
      value: input.accessToken,
      options: buildCookieOptions(input.isProduction, input.cookieDomain)
    },
    refresh: {
      name: "platform_refresh",
      value: input.refreshToken,
      options: buildCookieOptions(input.isProduction, input.cookieDomain)
    },
    csrf: {
      name: "platform_csrf",
      value: csrfToken,
      options: csrfCookieOptions(input.isProduction, input.cookieDomain)
    },
    csrfToken
  };
}
