import { randomUUID } from "crypto";
import { organizationInvitesRepository, prisma } from "@platform/database";
import { expiresInDays, sha256 } from "@platform/shared/security";

export async function createOrganizationInvite(input: {
  organizationId: string;
  email: string;
  role: "OWNER" | "ADMIN" | "DEVELOPER" | "VIEWER";
  createdByUserId: string;
}) {
  const rawToken = randomUUID() + randomUUID();
  const tokenHash = sha256(rawToken);

  const invite = await organizationInvitesRepository.create({
    id: randomUUID(),
    organizationId: input.organizationId,
    email: input.email,
    role: input.role,
    tokenHash,
    expiresAt: expiresInDays(7),
    createdByUserId: input.createdByUserId
  });

  return {
    invite,
    rawToken
  };
}

export async function acceptOrganizationInvite(input: {
  rawToken: string;
  userId: string;
  userEmail: string;
}) {
  const invite = await organizationInvitesRepository.findActiveByTokenHash(sha256(input.rawToken));
  if (!invite) throw new Error("Invite not found or expired");
  if (invite.email.toLowerCase() !== input.userEmail.toLowerCase()) {
    throw new Error("Invite email does not match current user");
  }

  await prisma.organizationMembership.upsert({
    where: {
      organizationId_userId: {
        organizationId: invite.organizationId,
        userId: input.userId
      }
    },
    update: {
      role: invite.role
    },
    create: {
      organizationId: invite.organizationId,
      userId: input.userId,
      role: invite.role
    }
  });

  await organizationInvitesRepository.markAccepted(invite.id);

  return invite;
}
