import "dotenv/config";
import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { registerAuthRoutes } from "./modules/auth/routes";
import { registerOrganizationRoutes } from "./modules/organizations/routes";
import { registerProjectRoutes } from "./modules/projects/routes";
import { registerVersionRoutes } from "./modules/versions/routes";
import { registerJobRoutes } from "./modules/jobs/routes";
import { errorHandler } from "./middleware/errorHandler";
import { notFoundHandler } from "./middleware/notFound";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: true, credentials: true }));
  app.use(cookieParser());
  app.use(express.json({ limit: "1mb" }));
  app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "api-platform" });
  });

  app.get("/api/readiness", (_req, res) => {
    res.json({ ok: true, readiness: "ready" });
  });

  registerAuthRoutes(app);
  registerOrganizationRoutes(app);
  registerProjectRoutes(app);
  registerVersionRoutes(app);
  registerJobRoutes(app);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
