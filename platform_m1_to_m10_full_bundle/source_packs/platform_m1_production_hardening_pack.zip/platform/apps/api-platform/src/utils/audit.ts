import { randomUUID } from "crypto";
import { auditLogsRepository } from "@platform/database";

export async function writeAuditLog(input: {
  actorUserId?: string | null;
  organizationId?: string | null;
  projectId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  metadataJson?: unknown;
}) {
  return auditLogsRepository.create({
    id: randomUUID(),
    ...input
  });
}
