import { prisma } from "../client";

export const refreshTokensRepository = {
  create(data: {
    id: string;
    userId: string;
    tokenHash: string;
    expiresAt: Date;
  }) {
    return prisma.refreshToken.create({ data });
  },

  findByTokenHash(tokenHash: string) {
    return prisma.refreshToken.findUnique({ where: { tokenHash } });
  },

  revoke(tokenHash: string, revokedAt = new Date()) {
    return prisma.refreshToken.update({
      where: { tokenHash },
      data: { revokedAt }
    });
  },

  revokeAllForUser(userId: string, revokedAt = new Date()) {
    return prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt }
    });
  },

  deleteExpired(now = new Date()) {
    return prisma.refreshToken.deleteMany({
      where: {
        OR: [
          { expiresAt: { lt: now } },
          { revokedAt: { not: null } }
        ]
      }
    });
  }
};
