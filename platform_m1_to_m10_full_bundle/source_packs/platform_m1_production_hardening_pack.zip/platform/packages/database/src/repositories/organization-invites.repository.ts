import { prisma } from "../client";

export const organizationInvitesRepository = {
  create(data: {
    id: string;
    organizationId: string;
    email: string;
    role: "OWNER" | "ADMIN" | "DEVELOPER" | "VIEWER";
    tokenHash: string;
    expiresAt: Date;
    createdByUserId: string;
  }) {
    return prisma.organizationInvite.create({ data });
  },

  findActiveByTokenHash(tokenHash: string, now = new Date()) {
    return prisma.organizationInvite.findFirst({
      where: {
        tokenHash,
        acceptedAt: null,
        expiresAt: { gt: now }
      }
    });
  },

  markAccepted(id: string, acceptedAt = new Date()) {
    return prisma.organizationInvite.update({
      where: { id },
      data: { acceptedAt }
    });
  },

  expireOld(now = new Date()) {
    return prisma.organizationInvite.updateMany({
      where: {
        acceptedAt: null,
        expiresAt: { lt: now }
      },
      data: { acceptedAt: now }
    });
  }
};
