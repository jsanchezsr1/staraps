import { prisma } from "../client";

export const auditLogsRepository = {
  create(data: {
    id: string;
    actorUserId?: string | null;
    organizationId?: string | null;
    projectId?: string | null;
    action: string;
    entityType: string;
    entityId?: string | null;
    metadataJson?: unknown;
  }) {
    return prisma.auditLog.create({ data });
  },

  listForProject(projectId: string) {
    return prisma.auditLog.findMany({
      where: { projectId },
      orderBy: { createdAt: "desc" }
    });
  }
};
