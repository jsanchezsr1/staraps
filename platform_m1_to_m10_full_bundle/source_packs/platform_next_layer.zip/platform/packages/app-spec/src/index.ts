import { z } from "zod";

export const APP_SPEC_SCHEMA_VERSION = "1.0.0" as const;

const appFieldTypeSchema = z.enum(["string", "number", "boolean", "date", "text", "relation"]);
const relationKindSchema = z.enum(["one-to-one", "one-to-many", "many-to-many"]);
const pageTypeSchema = z.enum(["list", "detail", "form", "dashboard", "custom"]);
const authProviderSchema = z.enum(["email", "google", "github"]);
const targetPlatformSchema = z.enum(["web", "mobile", "admin"]);
const apiActionSchema = z.enum(["list", "get", "create", "update", "delete", "custom"]);
const httpMethodSchema = z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]);

export const AppFieldSchema = z.object({
  name: z.string().min(1),
  type: appFieldTypeSchema,
  required: z.boolean().optional().default(false),
  unique: z.boolean().optional().default(false),
  list: z.boolean().optional().default(false),
  relation: z.object({
    model: z.string().min(1),
    kind: relationKindSchema
  }).optional()
});

export const AppModelSchema = z.object({
  name: z.string().min(1),
  fields: z.array(AppFieldSchema).min(1)
});

export const AppPageSchema = z.object({
  name: z.string().min(1),
  path: z.string().min(1),
  type: pageTypeSchema,
  model: z.string().optional(),
  components: z.array(z.string()).optional().default([]),
  authRequired: z.boolean().optional().default(true)
});

export const ApiEndpointSchema = z.object({
  name: z.string().min(1),
  method: httpMethodSchema,
  path: z.string().min(1),
  model: z.string().optional(),
  action: apiActionSchema.optional(),
  authRequired: z.boolean().optional().default(true)
});

export const UIComponentSpecSchema = z.object({
  name: z.string().min(1),
  type: z.string().min(1),
  props: z.record(z.any()).optional().default({})
});

export const IntegrationSpecSchema = z.object({
  name: z.string().min(1),
  provider: z.string().min(1),
  config: z.record(z.any()).optional().default({}),
  enabled: z.boolean().optional().default(true)
});

export const WorkflowSpecSchema = z.object({
  name: z.string().min(1),
  trigger: z.object({
    type: z.string().min(1),
    config: z.record(z.any()).optional().default({})
  }),
  steps: z.array(z.object({
    name: z.string().min(1),
    type: z.string().min(1),
    config: z.record(z.any()).optional().default({})
  })).min(1)
});

export const AppSpecSchema = z.object({
  meta: z.object({
    name: z.string().min(1),
    slug: z.string().min(1),
    description: z.string().optional(),
    version: z.string().default(APP_SPEC_SCHEMA_VERSION),
    targetPlatforms: z.array(targetPlatformSchema).min(1).default(["web", "admin"])
  }),
  auth: z.object({
    enabled: z.boolean(),
    providers: z.array(authProviderSchema).default(["email"]),
    roles: z.array(z.string()).optional().default([])
  }).optional(),
  models: z.array(AppModelSchema).default([]),
  pages: z.array(AppPageSchema).default([]),
  apis: z.array(ApiEndpointSchema).default([]),
  components: z.array(UIComponentSpecSchema).optional().default([]),
  integrations: z.array(IntegrationSpecSchema).optional().default([]),
  workflows: z.array(WorkflowSpecSchema).optional().default([])
});

export type AppSpec = z.infer<typeof AppSpecSchema>;

export function parseAppSpec(input: unknown): AppSpec {
  return AppSpecSchema.parse(input);
}

export function createEmptyAppSpec(input: {
  name: string;
  slug: string;
  description?: string;
  targetPlatforms?: Array<"web" | "mobile" | "admin">;
}): AppSpec {
  return AppSpecSchema.parse({
    meta: {
      name: input.name,
      slug: input.slug,
      description: input.description,
      version: APP_SPEC_SCHEMA_VERSION,
      targetPlatforms: input.targetPlatforms?.length ? input.targetPlatforms : ["web", "admin"]
    },
    auth: {
      enabled: true,
      providers: ["email"],
      roles: ["owner", "admin"]
    },
    models: [],
    pages: [],
    apis: [],
    components: [],
    integrations: [],
    workflows: []
  });
}
