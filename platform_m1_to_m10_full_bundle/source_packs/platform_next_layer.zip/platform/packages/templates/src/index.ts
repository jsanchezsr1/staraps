export type TemplateDescriptor = {
  key: string;
  outputPath: string;
  description: string;
};

export const templateRegistry: TemplateDescriptor[] = [
  {
    key: "frontend/page-list",
    outputPath: "app/frontend/src/app/[resource]/page.tsx",
    description: "Generates a list page for a model."
  },
  {
    key: "backend/route-crud",
    outputPath: "app/backend/src/routes/[resource].routes.ts",
    description: "Generates CRUD routes for a model."
  },
  {
    key: "database/prisma-model",
    outputPath: "app/database/prisma/schema.prisma",
    description: "Generates Prisma model definitions."
  },
  {
    key: "admin/page-list",
    outputPath: "app/admin/src/app/[resource]/page.tsx",
    description: "Generates an admin list page for a model."
  },
  {
    key: "mobile/screen-list",
    outputPath: "app/mobile/src/screens/[resource]ListScreen.tsx",
    description: "Generates a mobile list screen for a model."
  }
];
