import type { AppSpec } from "@platform/app-spec";

export function generateMobile(_spec: AppSpec): string[] {
  return ["mobile generation scaffold"];
}
