import type { AppSpec } from "@platform/app-spec";

export function generateBackend(_spec: AppSpec): string[] {
  return ["backend generation scaffold"];
}
