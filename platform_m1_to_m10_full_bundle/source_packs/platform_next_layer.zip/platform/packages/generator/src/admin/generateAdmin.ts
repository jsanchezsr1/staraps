import type { AppSpec } from "@platform/app-spec";

export function generateAdmin(_spec: AppSpec): string[] {
  return ["admin generation scaffold"];
}
