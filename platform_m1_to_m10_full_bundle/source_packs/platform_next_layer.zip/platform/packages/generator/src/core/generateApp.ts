import path from "path";
import type { AppSpec } from "@platform/app-spec";
import { buildPlan } from "./buildPlan";
import { writeGeneratedFiles } from "./writeFiles";

export async function generateApp(input: {
  projectId: string;
  versionId: string;
  outputRoot: string;
  spec: AppSpec;
}) {
  const plan = buildPlan(input.spec);
  const baseDir = path.join(input.outputRoot, input.projectId, input.versionId);

  const files = [
    {
      relativePath: "manifest.json",
      content: JSON.stringify(
        {
          projectId: input.projectId,
          versionId: input.versionId,
          generatedAt: new Date().toISOString(),
          modules: plan.modules,
          files: 1
        },
        null,
        2
      )
    }
  ];

  await writeGeneratedFiles(baseDir, files);

  return {
    baseDir,
    plan
  };
}
