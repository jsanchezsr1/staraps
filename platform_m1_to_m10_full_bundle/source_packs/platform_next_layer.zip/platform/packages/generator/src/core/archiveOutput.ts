export async function archiveOutput(_outputDir: string): Promise<string> {
  return "archive-output-placeholder.zip";
}
