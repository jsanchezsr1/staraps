import type { AppSpec } from "@platform/app-spec";

export function generateFrontend(_spec: AppSpec): string[] {
  return ["frontend generation scaffold"];
}
