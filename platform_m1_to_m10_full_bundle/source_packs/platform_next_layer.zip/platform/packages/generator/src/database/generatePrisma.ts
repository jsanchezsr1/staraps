import type { AppSpec } from "@platform/app-spec";

export function generatePrisma(_spec: AppSpec): string {
  return "// generated prisma schema scaffold";
}
