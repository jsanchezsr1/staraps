import { NextFunction, Request, Response } from "express";

export function requireOrgRole(_roles: Array<"OWNER" | "ADMIN" | "DEVELOPER" | "VIEWER">) {
  return (_req: Request, _res: Response, next: NextFunction): void => {
    next();
  };
}
