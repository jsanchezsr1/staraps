import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export type PlatformRole = "OWNER" | "ADMIN" | "DEVELOPER" | "VIEWER";

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function signJwt(payload: Record<string, unknown>, secret: string): string {
  return jwt.sign(payload, secret, { expiresIn: "7d" });
}

export function verifyJwt(token: string, secret: string): Record<string, unknown> {
  return jwt.verify(token, secret) as Record<string, unknown>;
}
