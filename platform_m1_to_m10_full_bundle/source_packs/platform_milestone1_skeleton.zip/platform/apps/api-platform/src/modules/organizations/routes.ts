import { Express } from "express";

export function registerOrganizationRoutes(app: Express): void {
  app.post("/api/organizations", async (req, res) => {
    res.status(501).json({ message: "Create organization scaffold.", payload: req.body });
  });

  app.get("/api/organizations", async (_req, res) => {
    res.status(501).json({ message: "List organizations scaffold." });
  });

  app.post("/api/organizations/:id/invite", async (req, res) => {
    res.status(501).json({ message: "Invite member scaffold.", params: req.params, payload: req.body });
  });

  app.patch("/api/organizations/:id/members/:memberId/role", async (req, res) => {
    res.status(501).json({ message: "Update member role scaffold.", params: req.params, payload: req.body });
  });
}
