import { Express } from "express";

export function registerJobRoutes(app: Express): void {
  app.get("/api/jobs/:jobId", async (req, res) => {
    res.status(501).json({ message: "Get job scaffold.", params: req.params });
  });

  app.get("/api/jobs/:jobId/logs", async (req, res) => {
    res.status(501).json({ message: "Get job logs scaffold.", params: req.params });
  });

  app.get("/api/artifacts/:artifactId/download", async (req, res) => {
    res.status(501).json({ message: "Artifact download scaffold.", params: req.params });
  });
}
