import { Express } from "express";

export function registerVersionRoutes(app: Express): void {
  app.post("/api/projects/:id/versions", async (req, res) => {
    res.status(501).json({ message: "Create version scaffold.", params: req.params, payload: req.body });
  });

  app.get("/api/projects/:id/versions", async (req, res) => {
    res.status(501).json({ message: "List versions scaffold.", params: req.params });
  });

  app.get("/api/projects/:id/versions/:versionId", async (req, res) => {
    res.status(501).json({ message: "Get version scaffold.", params: req.params });
  });

  app.post("/api/projects/:id/versions/:versionId/rollback", async (req, res) => {
    res.status(501).json({ message: "Rollback version scaffold.", params: req.params });
  });
}
