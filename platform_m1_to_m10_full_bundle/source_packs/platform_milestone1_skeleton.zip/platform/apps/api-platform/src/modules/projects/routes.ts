import { Express } from "express";

export function registerProjectRoutes(app: Express): void {
  app.post("/api/projects", async (req, res) => {
    res.status(501).json({ message: "Create project scaffold.", payload: req.body });
  });

  app.get("/api/projects/:id", async (req, res) => {
    res.status(501).json({ message: "Get project scaffold.", params: req.params });
  });

  app.patch("/api/projects/:id", async (req, res) => {
    res.status(501).json({ message: "Update project scaffold.", params: req.params, payload: req.body });
  });

  app.delete("/api/projects/:id", async (req, res) => {
    res.status(501).json({ message: "Delete project scaffold.", params: req.params });
  });

  app.post("/api/projects/:id/generate", async (req, res) => {
    res.status(501).json({ message: "Generate project scaffold.", params: req.params, payload: req.body });
  });
}
