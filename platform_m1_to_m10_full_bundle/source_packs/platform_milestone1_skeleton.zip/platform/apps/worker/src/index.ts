import "dotenv/config";
import { Queue, Worker } from "bullmq";
import IORedis from "ioredis";
import { env, logger } from "@platform/shared";

export type GenerationJobPayload = {
  organizationId: string;
  projectId: string;
  versionId: string;
  requestedByUserId: string;
};

const connection = new IORedis(env("REDIS_URL", "redis://localhost:6379"), {
  maxRetriesPerRequest: null
});

export const generationQueue = new Queue<GenerationJobPayload>("app-generation", {
  connection
});

const worker = new Worker<GenerationJobPayload>(
  "app-generation",
  async (job) => {
    logger.info("Processing generation job", job.id, job.data);
    return {
      ok: true,
      message: "Worker scaffold processed the job."
    };
  },
  { connection }
);

worker.on("completed", (job) => {
  logger.info("Generation job completed", job?.id);
});

worker.on("failed", (job, err) => {
  logger.error("Generation job failed", job?.id, err.message);
});

logger.info("Worker running.");
