import type { AppSpec } from "@platform/app-spec";
import { toKebabCase } from "../utils/naming";

export function generateFrontend(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  const files: Array<{ relativePath: string; content: string }> = [
    {
      relativePath: "app/frontend/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-frontend`,
        private: true,
        scripts: { dev: "next dev", build: "next build", start: "next start" },
        dependencies: { next: "^14.2.5", react: "^18.3.1", "react-dom": "^18.3.1" }
      }, null, 2)
    },
    {
      relativePath: "app/frontend/src/app/page.tsx",
      content: `export default function HomePage() {\n  return <main><h1>${spec.meta.name}</h1><p>${spec.meta.description || "Generated frontend app"}</p></main>;\n}\n`
    }
  ];

  for (const page of spec.pages) {
    const pagePath = page.path === "/" ? "index" : page.path.slice(1);
    const routeFile = `app/frontend/src/app/${pagePath}/page.tsx`;
    files.push({
      relativePath: routeFile,
      content: `export default function ${page.name}Page() {\n  return <main><h1>${page.name}</h1><p>Generated ${page.type} page${page.model ? ` for ${page.model}` : ""}.</p></main>;\n}\n`
    });
  }

  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    files.push({
      relativePath: `app/frontend/src/components/${model.name}Table.tsx`,
      content: `export function ${model.name}Table() {\n  return <div>${model.name} table placeholder</div>;\n}\n`
    });
    files.push({
      relativePath: `app/frontend/src/components/${model.name}Form.tsx`,
      content: `export function ${model.name}Form() {\n  return <form>${model.name} form placeholder</form>;\n}\n`
    });
  }

  return files;
}
