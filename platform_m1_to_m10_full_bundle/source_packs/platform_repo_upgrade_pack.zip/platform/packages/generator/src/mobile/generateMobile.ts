import type { AppSpec } from "@platform/app-spec";

export function generateMobile(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  const files: Array<{ relativePath: string; content: string }> = [
    {
      relativePath: "app/mobile/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-mobile`,
        private: true,
        scripts: { start: "expo start" },
        dependencies: { expo: "^51.0.0", react: "^18.3.1", "react-native": "^0.74.0" }
      }, null, 2)
    },
    {
      relativePath: "app/mobile/App.tsx",
      content: `export default function App() {\n  return null;\n}\n`
    }
  ];

  for (const model of spec.models) {
    files.push({
      relativePath: `app/mobile/src/screens/${model.name}ListScreen.tsx`,
      content: `export function ${model.name}ListScreen() {\n  return null;\n}\n`
    });
  }

  return files;
}
