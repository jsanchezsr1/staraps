import prettier from "prettier";

export async function formatCode(content: string, parser: prettier.BuiltInParserName): Promise<string> {
  return prettier.format(content, { parser });
}
