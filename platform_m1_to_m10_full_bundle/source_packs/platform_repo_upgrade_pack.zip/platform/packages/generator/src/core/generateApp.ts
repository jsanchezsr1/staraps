import path from "path";
import type { AppSpec } from "@platform/app-spec";
import { buildPlan } from "./buildPlan";
import { writeGeneratedFiles } from "./writeFiles";
import { archiveOutput } from "./archiveOutput";
import { generateFrontend } from "../frontend/generateFrontend";
import { generateBackend } from "../backend/generateBackend";
import { generatePrisma } from "../database/generatePrisma";
import { generateAdmin } from "../admin/generateAdmin";
import { generateMobile } from "../mobile/generateMobile";

export async function generateApp(input: {
  projectId: string;
  versionId: string;
  outputRoot: string;
  spec: AppSpec;
}) {
  const plan = buildPlan(input.spec);
  const baseDir = path.join(input.outputRoot, input.projectId, input.versionId);

  const files = [
    {
      relativePath: "manifest.json",
      content: JSON.stringify(
        {
          projectId: input.projectId,
          versionId: input.versionId,
          generatedAt: new Date().toISOString(),
          modules: plan.modules
        },
        null,
        2
      )
    },
    ...generateFrontend(input.spec),
    ...generateBackend(input.spec),
    ...generatePrisma(input.spec)
  ];

  if (plan.modules.includes("admin")) files.push(...generateAdmin(input.spec));
  if (plan.modules.includes("mobile")) files.push(...generateMobile(input.spec));

  await writeGeneratedFiles(baseDir, files);

  const zipPath = await archiveOutput(baseDir);

  return {
    baseDir,
    zipPath,
    plan,
    fileCount: files.length
  };
}
