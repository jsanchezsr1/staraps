import "dotenv/config";
import { Worker } from "bullmq";
import IORedis from "ioredis";
import fs from "fs-extra";
import path from "path";
import { env, logger } from "@platform/shared";
import { generationJobsRepository, prisma, GenerationJobStatus, projectVersionsRepository } from "@platform/database";
import { generateApp } from "@platform/generator";

type GenerationJobPayload = {
  organizationId: string;
  projectId: string;
  versionId: string;
  requestedByUserId: string;
  generationJobId: string;
};

const connection = new IORedis(env("REDIS_URL", "redis://localhost:6379"), {
  maxRetriesPerRequest: null
});

const worker = new Worker<GenerationJobPayload>(
  "app-generation",
  async (job) => {
    logger.info("Processing generation job", job.id, job.data);

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.RUNNING,
      startedAt: new Date(),
      log: "Generation started"
    });

    const version = await projectVersionsRepository.findById(job.data.versionId);
    if (!version) {
      throw new Error("Project version not found");
    }

    const outputRoot = path.resolve(process.cwd(), "../../generated-apps");
    await fs.ensureDir(outputRoot);

    const result = await generateApp({
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      outputRoot,
      spec: version.appSpecJson as any
    });

    const stat = await fs.stat(result.zipPath);

    const artifact = await prisma.generatedArtifact.create({
      data: {
        generationJobId: job.data.generationJobId,
        fileName: path.basename(result.zipPath),
        filePath: result.zipPath,
        size: BigInt(stat.size)
      }
    });

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.COMPLETED,
      finishedAt: new Date(),
      artifactPath: artifact.filePath,
      log: `Generation completed successfully. Files generated: ${result.fileCount}`
    });

    return {
      ok: true,
      artifactId: artifact.id
    };
  },
  { connection, concurrency: 2 }
);

worker.on("completed", (job) => {
  logger.info("Generation job completed", job?.id);
});

worker.on("failed", async (job, err) => {
  logger.error("Generation job failed", job?.id, err.message);

  if (job?.data?.generationJobId) {
    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.FAILED,
      finishedAt: new Date(),
      log: err.message
    });
  }
});

logger.info("Worker running.");
