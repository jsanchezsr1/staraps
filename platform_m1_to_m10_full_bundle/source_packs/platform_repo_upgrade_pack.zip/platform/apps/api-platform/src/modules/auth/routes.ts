import { Express } from "express";
import { hashPassword, signJwt, verifyPassword, buildCookieOptions } from "@platform/auth";
import { env } from "@platform/shared";
import { usersRepository } from "@platform/database";
import { validateBody } from "../../validators/common";
import { loginSchema, registerSchema } from "../../validators/auth.dto";
import { requireAuth } from "../../middleware/requireAuth";

export function registerAuthRoutes(app: Express): void {
  app.post("/api/auth/register", validateBody(registerSchema), async (req, res) => {
    try {
      const { email, password, name } = req.body;

      const existingUser = await usersRepository.findByEmail(email);
      if (existingUser) {
        res.status(409).json({ message: "Email already registered" });
        return;
      }

      const passwordHash = await hashPassword(password);
      const user = await usersRepository.create({ email, passwordHash, name });

      const token = signJwt({ sub: user.id, email: user.email }, env("JWT_SECRET"));
      res.cookie(
        "platform_token",
        token,
        buildCookieOptions(env("NODE_ENV", "development") === "production", process.env.COOKIE_DOMAIN)
      );

      res.status(201).json({
        user: { id: user.id, email: user.email, name: user.name },
        token
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to register", error: String(error) });
    }
  });

  app.post("/api/auth/login", validateBody(loginSchema), async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await usersRepository.findByEmail(email);

      if (!user) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const valid = await verifyPassword(password, user.passwordHash);
      if (!valid) {
        res.status(401).json({ message: "Invalid credentials" });
        return;
      }

      const token = signJwt({ sub: user.id, email: user.email }, env("JWT_SECRET"));
      res.cookie(
        "platform_token",
        token,
        buildCookieOptions(env("NODE_ENV", "development") === "production", process.env.COOKIE_DOMAIN)
      );

      res.json({
        user: { id: user.id, email: user.email, name: user.name },
        token
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to login", error: String(error) });
    }
  });

  app.post("/api/auth/logout", requireAuth, async (_req, res) => {
    res.clearCookie("platform_token", {
      path: "/",
      httpOnly: true,
      secure: env("NODE_ENV", "development") === "production",
      sameSite: "lax"
    });
    res.json({ ok: true });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });
}
