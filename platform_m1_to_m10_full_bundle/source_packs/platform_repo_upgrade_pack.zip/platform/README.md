# Platform

Upgraded monorepo scaffold for a Base44-style competitor.

## Included
- `apps/web-platform` - Next.js control plane
- `apps/api-platform` - Express API with stronger auth, validation, and RBAC
- `apps/worker` - BullMQ worker
- `packages/database` - Prisma schema, migrations, repositories
- `packages/app-spec` - App Spec zod schema/types
- `packages/auth` - auth/session helpers
- `packages/shared` - logger/env/errors/common helpers
- `packages/templates` - template registry
- `packages/generator` - generation pipeline with actual deterministic output

## Quick start
1. Copy `.env.example` to `.env`
2. Start infra:
   - `docker compose up -d`
3. Install deps:
   - `pnpm install`
4. Generate Prisma client:
   - `pnpm --filter @platform/database prisma:generate`
5. Run migrations:
   - `pnpm --filter @platform/database prisma:migrate`
6. Run services:
   - `pnpm dev`

## Notes
This is a significantly improved scaffold, but it is still not a completed production product.
It now includes:
- artifact ZIP creation
- stronger auth/session handling
- zod request validation
- RBAC enforcement middleware
- deterministic generated app output beyond a manifest
- Prisma migration bootstrap files
