import path from "path";
import { buildPlan } from "./buildPlan";
import { writeGeneratedFiles } from "./writeFiles";
import { archiveOutput } from "./archiveOutput";
import { generatedDockerCompose } from "./generatedDockerCompose";
import { renderModuleFiles } from "./renderModule";
import { formatCode } from "../utils/formatting";

export async function generateApp(input: any) {
  const plan = buildPlan(input.spec);
  const baseDir = path.join(input.outputRoot, input.projectId, input.versionId);

  const moduleFiles = await Promise.all(
    renderModuleFiles(input.spec).map(async (file) => ({
      ...file,
      content: await formatCode(file.content)
    }))
  );

  const files = [
    {
      relativePath: "manifest.json",
      content: JSON.stringify({
        projectId: input.projectId,
        versionId: input.versionId,
        generatedAt: new Date().toISOString(),
        modules: plan.modules,
        modelCount: plan.modelCount,
        pageCount: plan.pageCount,
        apiCount: plan.apiCount
      }, null, 2)
    },
    {
      relativePath: "docker-compose.generated.yml",
      content: generatedDockerCompose()
    },
    ...moduleFiles
  ];

  await writeGeneratedFiles(baseDir, files);
  const zipPath = await archiveOutput(baseDir);

  return { baseDir, zipPath, plan, fileCount: files.length };
}
