import { fieldTsType } from "../utils/fieldMapping";
import { toKebabCase, toPascalCase } from "../utils/naming";

function renderModelType(model: any): string {
  const fields = model.fields
    .filter((field: any) => field.type !== "relation")
    .map((field: any) => `  ${field.name}${field.required ? "" : "?"}: ${fieldTsType(field)};`)
    .join("\n");

  return `export type ${model.name}Entity = {
  id: string;
${fields}
  createdAt: string;
  updatedAt: string;
};
`;
}

function renderTableComponent(model: any): string {
  const pascal = toPascalCase(model.name);
  const visibleFields = model.fields.filter((field: any) => field.type !== "relation").slice(0, 4);
  const headers = visibleFields.map((field: any) => `<th>${field.name}</th>`).join("");
  const cells = visibleFields.map((field: any) => `<td>{String(item.${field.name} ?? "")}</td>`).join("");

  return `import type { ${model.name}Entity } from "../types/${toKebabCase(model.name)}";

export function ${pascal}Table({ items }: { items: ${model.name}Entity[] }) {
  return (
    <table>
      <thead>
        <tr>${headers}</tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.id}>${cells}</tr>
        ))}
      </tbody>
    </table>
  );
}
`;
}

function renderFormComponent(model: any): string {
  const pascal = toPascalCase(model.name);
  const formFields = model.fields
    .filter((field: any) => field.type !== "relation")
    .map((field: any) => {
      const type = field.type === "number" ? "number" : field.type === "date" ? "date" : "text";
      return `<label>${field.name}<input name="${field.name}" type="${type}" /></label>`;
    })
    .join("\n      ");

  return `export function ${pascal}Form() {
  return (
    <form>
      ${formFields}
      <button type="submit">Save</button>
    </form>
  );
}
`;
}

function renderListPage(model: any): string {
  const pascal = toPascalCase(model.name);
  const resource = toKebabCase(model.name);

  return `import Link from "next/link";
import { ${pascal}Table } from "../../components/${pascal}Table";

export default async function ${pascal}ListPage() {
  const data: any[] = [];
  return (
    <main>
      <h1>${pascal} List</h1>
      <Link href="/${resource}/new">Create ${pascal}</Link>
      <${pascal}Table items={data} />
    </main>
  );
}
`;
}

function renderNewPage(model: any): string {
  const pascal = toPascalCase(model.name);
  return `import { ${pascal}Form } from "../../../components/${pascal}Form";

export default function Create${pascal}Page() {
  return (
    <main>
      <h1>Create ${pascal}</h1>
      <${pascal}Form />
    </main>
  );
}
`;
}

function renderDetailPage(model: any): string {
  const pascal = toPascalCase(model.name);
  return `export default function ${pascal}DetailPage({ params }: { params: { id: string } }) {
  return (
    <main>
      <h1>${pascal} Detail</h1>
      <p>Record ID: {params.id}</p>
    </main>
  );
}
`;
}

export function generateFrontend(spec: any) {
  const files = [
    {
      relativePath: "app/frontend/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-frontend`,
        private: true,
        scripts: { dev: "next dev", build: "next build", start: "next start" },
        dependencies: { next: "^14.2.5", react: "^18.3.1", "react-dom": "^18.3.1" }
      }, null, 2),
      parser: "json"
    },
    {
      relativePath: "app/frontend/src/app/page.tsx",
      content: `export default function HomePage() {\n  return <main><h1>${spec.meta.name}</h1><p>${spec.meta.description || "Generated frontend app"}</p></main>;\n}\n`,
      parser: "typescript"
    }
  ];

  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    const pascal = toPascalCase(model.name);

    files.push(
      { relativePath: `app/frontend/src/types/${resource}.ts`, content: renderModelType(model), parser: "typescript" },
      { relativePath: `app/frontend/src/components/${pascal}Table.tsx`, content: renderTableComponent(model), parser: "typescript" },
      { relativePath: `app/frontend/src/components/${pascal}Form.tsx`, content: renderFormComponent(model), parser: "typescript" },
      { relativePath: `app/frontend/src/app/${resource}/page.tsx`, content: renderListPage(model), parser: "typescript" },
      { relativePath: `app/frontend/src/app/${resource}/new/page.tsx`, content: renderNewPage(model), parser: "typescript" },
      { relativePath: `app/frontend/src/app/${resource}/[id]/page.tsx`, content: renderDetailPage(model), parser: "typescript" }
    );
  }

  return files;
}
