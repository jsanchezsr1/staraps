export async function formatCode(content: string): Promise<string> {
  return content;
}
