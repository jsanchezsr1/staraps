import { prismaScalarType } from "../utils/fieldMapping";

function renderPrismaField(field: any): string[] {
  if (field.type === "relation" && field.relation) {
    const relationIdField = `${field.name}Id`;
    return [
      `  ${relationIdField} String?`,
      `  ${field.name} ${field.relation.model}? @relation(fields: [${relationIdField}], references: [id])`
    ];
  }

  const prismaType = prismaScalarType(field);
  const required = field.required ? "" : "?";
  const unique = field.unique ? " @unique" : "";
  return [`  ${field.name} ${prismaType}${required}${unique}`];
}

function renderPrismaModel(model: any): string {
  const renderedFields = model.fields.flatMap(renderPrismaField).join("\n");
  return [
    `model ${model.name} {`,
    `  id String @id @default(cuid())`,
    renderedFields,
    `  createdAt DateTime @default(now())`,
    `  updatedAt DateTime @updatedAt`,
    `}`
  ].filter(Boolean).join("\n");
}

export function generatePrisma(spec: any) {
  const modelBlocks = spec.models.map((model: any) => renderPrismaModel(model)).join("\n\n");
  const schema = [
    `generator client {`,
    `  provider = "prisma-client-js"`,
    `}`,
    ``,
    `datasource db {`,
    `  provider = "postgresql"`,
    `  url      = env("DATABASE_URL")`,
    `}`,
    ``,
    modelBlocks,
    ``
  ].join("\n");

  return [
    {
      relativePath: "app/database/prisma/schema.prisma",
      content: schema,
      parser: "prisma"
    },
    {
      relativePath: "app/database/README.md",
      content: "# Generated Database\n\nThis schema was generated from the App Spec models.\n",
      parser: "markdown"
    }
  ];
}
