import { fieldTsType, fieldZodType } from "../utils/fieldMapping";
import { toCamelCase, toKebabCase, toPascalCase } from "../utils/naming";

function renderValidator(model: any): string {
  const createFields = model.fields
    .filter((field: any) => field.type !== "relation")
    .map((field: any) => `  ${field.name}: ${field.required ? fieldZodType(field) : `${fieldZodType(field)}.optional()`}`)
    .join(",\n");

  const updateFields = model.fields
    .filter((field: any) => field.type !== "relation")
    .map((field: any) => `  ${field.name}: ${fieldZodType(field)}.optional()`)
    .join(",\n");

  return `import { z } from "zod";

export const create${model.name}Schema = z.object({
${createFields}
});

export const update${model.name}Schema = z.object({
${updateFields}
});

export type Create${model.name}Input = z.infer<typeof create${model.name}Schema>;
export type Update${model.name}Input = z.infer<typeof update${model.name}Schema>;
`;
}

function renderRepository(model: any): string {
  const pascal = toPascalCase(model.name);
  const camel = toCamelCase(model.name);
  const fieldsType = model.fields
    .filter((field: any) => field.type !== "relation")
    .map((field: any) => `  ${field.name}${field.required ? "" : "?"}: ${fieldTsType(field)};`)
    .join("\n");

  return `import crypto from "crypto";

export type ${pascal}Record = {
  id: string;
${fieldsType}
  createdAt: string;
  updatedAt: string;
};

const ${camel}Store: ${pascal}Record[] = [];

export const ${pascal}Repository = {
  list(): ${pascal}Record[] {
    return ${camel}Store;
  },

  getById(id: string): ${pascal}Record | undefined {
    return ${camel}Store.find((item) => item.id === id);
  },

  create(input: Omit<${pascal}Record, "id" | "createdAt" | "updatedAt">): ${pascal}Record {
    const now = new Date().toISOString();
    const record: ${pascal}Record = {
      id: crypto.randomUUID(),
      ...input,
      createdAt: now,
      updatedAt: now
    };
    ${camel}Store.push(record);
    return record;
  },

  update(id: string, input: Partial<Omit<${pascal}Record, "id" | "createdAt" | "updatedAt">>): ${pascal}Record | undefined {
    const record = ${camel}Store.find((item) => item.id === id);
    if (!record) return undefined;
    Object.assign(record, input, { updatedAt: new Date().toISOString() });
    return record;
  },

  delete(id: string): boolean {
    const index = ${camel}Store.findIndex((item) => item.id === id);
    if (index === -1) return false;
    ${camel}Store.splice(index, 1);
    return true;
  }
};
`;
}

function renderService(model: any): string {
  const pascal = toPascalCase(model.name);
  const resource = toKebabCase(model.name);
  return `import { ${pascal}Repository } from "../repositories/${resource}.repository";
import type { Create${pascal}Input, Update${pascal}Input } from "../validators/${resource}.schema";

export const ${pascal}Service = {
  list() {
    return ${pascal}Repository.list();
  },

  getById(id: string) {
    return ${pascal}Repository.getById(id);
  },

  create(input: Create${pascal}Input) {
    return ${pascal}Repository.create(input as any);
  },

  update(id: string, input: Update${pascal}Input) {
    return ${pascal}Repository.update(id, input as any);
  },

  delete(id: string) {
    return ${pascal}Repository.delete(id);
  }
};
`;
}

function renderController(model: any): string {
  const pascal = toPascalCase(model.name);
  const resource = toKebabCase(model.name);
  return `import { Request, Response } from "express";
import { ${pascal}Service } from "../services/${resource}.service";

export const ${pascal}Controller = {
  list(_req: Request, res: Response) {
    res.json(${pascal}Service.list());
  },

  getById(req: Request, res: Response) {
    const record = ${pascal}Service.getById(req.params.id);
    if (!record) {
      res.status(404).json({ message: "${pascal} not found" });
      return;
    }
    res.json(record);
  },

  create(req: Request, res: Response) {
    const record = ${pascal}Service.create(req.body);
    res.status(201).json(record);
  },

  update(req: Request, res: Response) {
    const record = ${pascal}Service.update(req.params.id, req.body);
    if (!record) {
      res.status(404).json({ message: "${pascal} not found" });
      return;
    }
    res.json(record);
  },

  delete(req: Request, res: Response) {
    const deleted = ${pascal}Service.delete(req.params.id);
    if (!deleted) {
      res.status(404).json({ message: "${pascal} not found" });
      return;
    }
    res.status(204).send();
  }
};
`;
}

function renderRoutes(model: any): string {
  const pascal = toPascalCase(model.name);
  const resource = toKebabCase(model.name);

  return `import { Router } from "express";
import { ${pascal}Controller } from "../controllers/${resource}.controller";
import { create${pascal}Schema, update${pascal}Schema } from "../validators/${resource}.schema";

const router = Router();

router.get("/", ${pascal}Controller.list);
router.get("/:id", ${pascal}Controller.getById);
router.post("/", (req, _res, next) => {
  req.body = create${pascal}Schema.parse(req.body);
  next();
}, ${pascal}Controller.create);
router.patch("/:id", (req, _res, next) => {
  req.body = update${pascal}Schema.parse(req.body);
  next();
}, ${pascal}Controller.update);
router.delete("/:id", ${pascal}Controller.delete);

export default router;
`;
}

function renderBackendIndex(spec: any): string {
  const imports = spec.models.map((model: any) => {
    const resource = toKebabCase(model.name);
    return `import ${resource}Router from "./routes/${resource}.routes";`;
  }).join("\n");

  const mounts = spec.models.map((model: any) => {
    const resource = toKebabCase(model.name);
    return `app.use("/api/${resource}", ${resource}Router);`;
  }).join("\n");

  return `import cors from "cors";
import express from "express";
${imports}

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

${mounts}

app.listen(3001, () => {
  console.log("Generated backend running on 3001");
});
`;
}

export function generateBackend(spec: any) {
  const files = [
    {
      relativePath: "app/backend/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-backend`,
        private: true,
        scripts: { dev: "tsx watch src/index.ts", build: "tsc", start: "node dist/index.js" },
        dependencies: { cors: "^2.8.5", express: "^4.19.2", zod: "^3.23.8" },
        devDependencies: { tsx: "^4.16.2", typescript: "^5.5.0" }
      }, null, 2),
      parser: "json"
    },
    {
      relativePath: "app/backend/src/index.ts",
      content: renderBackendIndex(spec),
      parser: "typescript"
    }
  ];

  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    files.push(
      { relativePath: `app/backend/src/validators/${resource}.schema.ts`, content: renderValidator(model), parser: "typescript" },
      { relativePath: `app/backend/src/repositories/${resource}.repository.ts`, content: renderRepository(model), parser: "typescript" },
      { relativePath: `app/backend/src/services/${resource}.service.ts`, content: renderService(model), parser: "typescript" },
      { relativePath: `app/backend/src/controllers/${resource}.controller.ts`, content: renderController(model), parser: "typescript" },
      { relativePath: `app/backend/src/routes/${resource}.routes.ts`, content: renderRoutes(model), parser: "typescript" }
    );
  }

  return files;
}
