import "dotenv/config";
import { Worker } from "bullmq";
import IORedis from "ioredis";
import fs from "fs-extra";
import path from "path";
import { logger } from "@platform/shared";
import { parseEnv } from "@platform/shared/env";
import {
  generationJobsRepository,
  platformJobsRepository,
  prisma,
  GenerationJobStatus,
  projectVersionsRepository
} from "@platform/database";
import { generateApp } from "@platform/generator";
import { runPluginHook } from "@platform/plugins/runtime";
import { runPreviewProvider } from "./providers/preview";
import { runDeploymentProvider } from "./providers/deployment";

type GenerationJobPayload = {
  organizationId: string;
  projectId: string;
  versionId: string;
  requestedByUserId: string;
  generationJobId: string;
};

type PlatformJobPayload = {
  platformJobId: string;
  projectId: string;
  versionId?: string;
  requestedByUserId?: string;
  type: "PREVIEW" | "DEPLOYMENT";
  target?: string;
};

const validatedEnv = parseEnv(process.env);

const connection = new IORedis(validatedEnv.REDIS_URL, {
  maxRetriesPerRequest: null
});

async function setProgress(generationJobId: string, progress: number, message: string, status?: GenerationJobStatus) {
  await generationJobsRepository.updateStatus(generationJobId, {
    status: status ?? GenerationJobStatus.RUNNING,
    log: `PROGRESS:${progress} ${message}`
  });
}

const generationWorker = new Worker<GenerationJobPayload>(
  "app-generation",
  async (job) => {
    logger.info("Processing generation job", job.id, job.data);

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.RUNNING,
      startedAt: new Date(),
      log: "PROGRESS:10 Generation started"
    });

    await runPluginHook("beforeGenerate", {
      organizationId: job.data.organizationId,
      projectId: job.data.projectId,
      versionId: job.data.versionId
    });

    const version = await projectVersionsRepository.findById(job.data.versionId);
    if (!version) throw new Error("Project version not found");

    await setProgress(job.data.generationJobId, 25, "Loaded project version");

    const outputRoot = path.resolve(process.cwd(), "../../generated-apps");
    await fs.ensureDir(outputRoot);

    await setProgress(job.data.generationJobId, 50, "Preparing output directory");

    const result = await generateApp({
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      outputRoot,
      spec: version.appSpecJson as any
    });

    await setProgress(job.data.generationJobId, 80, "Generated app and archived artifact");

    const stat = await fs.stat(result.zipPath);
    const checksum = await sha256File(result.zipPath);

    const artifact = await prisma.generatedArtifact.create({
      data: {
        generationJobId: job.data.generationJobId,
        fileName: path.basename(result.zipPath),
        filePath: result.zipPath,
        size: BigInt(stat.size),
        checksum
      }
    });

    await runPluginHook("afterGenerate", {
      organizationId: job.data.organizationId,
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      metadata: { artifactId: artifact.id }
    });

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.COMPLETED,
      finishedAt: new Date(),
      artifactPath: artifact.filePath,
      log: `PROGRESS:100 Generation completed successfully. Files generated: ${result.fileCount}`
    });

    return { ok: true, artifactId: artifact.id };
  },
  { connection, concurrency: 2 }
);

const previewWorker = new Worker<PlatformJobPayload>(
  "platform-preview",
  async (job) => {
    await runPluginHook("beforePreview", {
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      target: job.data.target
    });

    const result = await runPreviewProvider({
      provider: job.data.target || "local-docker",
      platformJobId: job.data.platformJobId,
      projectId: job.data.projectId,
      versionId: job.data.versionId
    });

    await runPluginHook("afterPreview", {
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      target: job.data.target
    });

    return result;
  },
  { connection, concurrency: 1 }
);

const deploymentWorker = new Worker<PlatformJobPayload>(
  "platform-deployment",
  async (job) => {
    await runPluginHook("beforeDeploy", {
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      target: job.data.target
    });

    const result = await runDeploymentProvider({
      provider: job.data.target || "local-docker",
      platformJobId: job.data.platformJobId,
      projectId: job.data.projectId
    });

    await runPluginHook("afterDeploy", {
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      target: job.data.target
    });

    return result;
  },
  { connection, concurrency: 1 }
);

generationWorker.on("completed", (job) => logger.info("Generation job completed", job?.id));
generationWorker.on("failed", async (job, err) => {
  logger.error("Generation job failed", job?.id, err.message);
  if (job?.data?.generationJobId) {
    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.FAILED,
      finishedAt: new Date(),
      log: `PROGRESS:100 FAILED ${err.message}`
    });
  }
});

previewWorker.on("failed", async (job, err) => {
  logger.error("Preview job failed", job?.id, err.message);
  if (job?.data?.platformJobId) {
    await platformJobsRepository.update(job.data.platformJobId, {
      status: "FAILED",
      finishedAt: new Date(),
      log: err.message
    });
  }
});

deploymentWorker.on("failed", async (job, err) => {
  logger.error("Deployment job failed", job?.id, err.message);
  if (job?.data?.platformJobId) {
    await platformJobsRepository.update(job.data.platformJobId, {
      status: "FAILED",
      finishedAt: new Date(),
      log: err.message
    });
  }
});

async function sha256File(filePath: string): Promise<string> {
  const crypto = await import("crypto");
  const buf = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

logger.info("Workers running.");
