import { runAwsEc2Preview } from "./awsEc2Preview";
import { runLocalDockerPreview } from "./localDockerPreview";

export async function runPreviewProvider(input: {
  provider: string;
  platformJobId: string;
  projectId: string;
  versionId?: string;
}) {
  switch (input.provider) {
    case "aws-ec2":
      return runAwsEc2Preview(input);
    case "local-docker":
    default:
      return runLocalDockerPreview(input);
  }
}
