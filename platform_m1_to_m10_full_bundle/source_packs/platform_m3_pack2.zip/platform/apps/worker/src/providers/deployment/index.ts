import { runAwsEc2Deployment } from "./awsEc2Deployment";
import { runLocalDockerDeployment } from "./localDockerDeployment";
import { runRailwayDeployment } from "./railwayDeployment";
import { runVercelDeployment } from "./vercelDeployment";

export async function runDeploymentProvider(input: {
  provider: string;
  platformJobId: string;
  projectId: string;
}) {
  switch (input.provider) {
    case "aws-ec2":
      return runAwsEc2Deployment(input);
    case "vercel":
      return runVercelDeployment(input);
    case "railway":
      return runRailwayDeployment(input);
    case "local-docker":
    default:
      return runLocalDockerDeployment(input);
  }
}
