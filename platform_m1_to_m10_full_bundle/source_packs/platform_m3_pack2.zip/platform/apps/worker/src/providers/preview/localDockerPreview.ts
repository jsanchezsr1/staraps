import { platformJobsRepository } from "@platform/database";

export async function runLocalDockerPreview(input: {
  platformJobId: string;
  projectId: string;
  versionId?: string;
}) {
  await platformJobsRepository.update(input.platformJobId, {
    status: "RUNNING",
    startedAt: new Date(),
    log: "Building preview using local Docker adapter"
  });

  await platformJobsRepository.update(input.platformJobId, {
    status: "COMPLETED",
    finishedAt: new Date(),
    previewUrl: `http://preview.localhost/${input.projectId}/${input.versionId || "latest"}`,
    log: "Preview build completed using local Docker adapter"
  });

  return { ok: true };
}
