import { platformJobsRepository } from "@platform/database";

export async function runAwsEc2Preview(input: {
  platformJobId: string;
  projectId: string;
  versionId?: string;
}) {
  await platformJobsRepository.update(input.platformJobId, {
    status: "RUNNING",
    startedAt: new Date(),
    log: "Preparing AWS EC2 preview deployment scaffold"
  });

  await platformJobsRepository.update(input.platformJobId, {
    status: "COMPLETED",
    finishedAt: new Date(),
    previewUrl: `https://preview-${input.projectId}.example.aws`,
    log: "AWS EC2 preview scaffold completed"
  });

  return { ok: true };
}
