export default function PluginsPage() {
  return (
    <main>
      <h1>Plugin Marketplace</h1>
      <p>Browse built-in and installable plugins for generation, deployment, integrations, and UI.</p>
    </main>
  );
}
