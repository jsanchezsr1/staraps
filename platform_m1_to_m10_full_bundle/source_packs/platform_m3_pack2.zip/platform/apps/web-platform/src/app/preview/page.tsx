export default function PreviewPage() {
  return (
    <main>
      <h1>Preview Jobs</h1>
      <p>Create and monitor preview environments here.</p>
      <ul>
        <li>Select version</li>
        <li>Choose preview provider</li>
        <li>Track preview URL and status</li>
      </ul>
    </main>
  );
}
