export default function DeploymentsPage() {
  return (
    <main>
      <h1>Deployments</h1>
      <p>Start deployment jobs and review deployment URLs/statuses.</p>
      <ul>
        <li>EC2 adapter scaffold</li>
        <li>Vercel adapter scaffold</li>
        <li>Railway adapter scaffold</li>
      </ul>
    </main>
  );
}
