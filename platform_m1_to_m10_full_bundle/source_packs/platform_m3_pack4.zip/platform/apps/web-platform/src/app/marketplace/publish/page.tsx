export default function PublishTemplatePage() {
  return (
    <main>
      <h1>Publish Template</h1>
      <p>Publish a reusable template into the marketplace catalog.</p>
    </main>
  );
}
