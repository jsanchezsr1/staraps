export default function TemplateInstallationsPage() {
  return (
    <main>
      <h1>Template Installations</h1>
      <p>Review template installations and the projects created from them.</p>
    </main>
  );
}
