export default function MarketplacePage() {
  return (
    <main>
      <h1>Template Marketplace</h1>
      <p>Browse built-in and published templates by category.</p>
      <ul>
        <li>CRM templates</li>
        <li>SaaS templates</li>
        <li>Marketplace templates</li>
        <li>Social templates</li>
        <li>Dashboard templates</li>
      </ul>
    </main>
  );
}
