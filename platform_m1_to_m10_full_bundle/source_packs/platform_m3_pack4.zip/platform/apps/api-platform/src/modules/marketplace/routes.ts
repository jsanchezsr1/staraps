import { randomUUID } from "crypto";
import { Express } from "express";
import {
  templateDefinitionsRepository,
  templateInstallationsRepository,
  OrganizationRole
} from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import { requireOrgRole } from "../../middleware/requireOrgRole";
import { validateBody } from "../../validators/common";
import {
  installTemplateSchema,
  publishTemplateSchema
} from "../../validators/template-marketplace.dto";
import { installMarketplaceTemplate, seedBuiltInMarketplaceTemplates } from "../../services/templateMarketplace";
import { writeAuditLog } from "../../utils/audit";

export function registerMarketplaceRoutes(app: Express): void {
  app.get("/api/marketplace/templates", requireAuth, async (_req, res) => {
    await seedBuiltInMarketplaceTemplates();
    const templates = await templateDefinitionsRepository.listPublished();
    res.json(templates);
  });

  app.get("/api/marketplace/templates/category/:category", requireAuth, async (req, res) => {
    await seedBuiltInMarketplaceTemplates();
    const templates = await templateDefinitionsRepository.listByCategory(req.params.category);
    res.json(templates);
  });

  app.get("/api/organizations/:id/template-installations", requireAuth, requireOrgRole([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN,
    OrganizationRole.DEVELOPER,
    OrganizationRole.VIEWER
  ]), async (req, res) => {
    const installations = await templateInstallationsRepository.listForOrganization(req.params.id);
    res.json(installations);
  });

  app.post("/api/organizations/:id/marketplace/install", requireAuth, requireOrgRole([
    OrganizationRole.OWNER,
    OrganizationRole.ADMIN,
    OrganizationRole.DEVELOPER
  ]), validateBody(installTemplateSchema), async (req, res) => {
    if (!req.user?.id) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const result = await installMarketplaceTemplate({
      organizationId: req.params.id,
      templateKey: req.body.templateKey,
      createdByUserId: req.user.id,
      projectName: req.body.projectName,
      projectDescription: req.body.projectDescription
    });

    await writeAuditLog({
      actorUserId: req.user.id,
      organizationId: req.params.id,
      projectId: result.project.id,
      action: "marketplace.template.install",
      entityType: "TemplateInstallation",
      entityId: result.installation.id,
      metadataJson: { templateKey: req.body.templateKey }
    });

    res.status(201).json(result);
  });

  app.post("/api/marketplace/templates/publish", requireAuth, validateBody(publishTemplateSchema), async (req, res) => {
    const template = await templateDefinitionsRepository.create({
      id: randomUUID(),
      key: req.body.key,
      name: req.body.name,
      slug: req.body.slug,
      description: req.body.description || null,
      category: req.body.category,
      version: req.body.version,
      thumbnailUrl: req.body.thumbnailUrl || null,
      templateSpecJson: req.body.templateSpecJson,
      tagsJson: req.body.tagsJson,
      isPublished: true
    });

    await writeAuditLog({
      actorUserId: req.user?.id,
      action: "marketplace.template.publish",
      entityType: "TemplateDefinition",
      entityId: template.id,
      metadataJson: { key: template.key }
    });

    res.status(201).json(template);
  });
}
