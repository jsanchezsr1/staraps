import { Express } from "express";
import { projectsRepository } from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import { slugify } from "../../utils/slugify";
import { generationJobsRepository, projectVersionsRepository } from "@platform/database";
import { generationQueue } from "@platform/worker/src/queue";

export function registerProjectRoutes(app: Express): void {
  app.post("/api/projects", requireAuth, async (req, res) => {
    try {
      const { organizationId, name, slug, description } = req.body as {
        organizationId?: string;
        name?: string;
        slug?: string;
        description?: string;
      };

      if (!req.user?.id) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      if (!organizationId || !name) {
        res.status(400).json({ message: "organizationId and name are required" });
        return;
      }

      const project = await projectsRepository.create({
        organizationId,
        name,
        slug: slug || slugify(name),
        description,
        createdByUserId: req.user.id
      });

      res.status(201).json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to create project", error: String(error) });
    }
  });

  app.get("/api/projects/:id", requireAuth, async (req, res) => {
    try {
      const project = await projectsRepository.findById(req.params.id);
      if (!project) {
        res.status(404).json({ message: "Project not found" });
        return;
      }

      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to get project", error: String(error) });
    }
  });

  app.patch("/api/projects/:id", requireAuth, async (req, res) => {
    try {
      const project = await projectsRepository.update(req.params.id, req.body);
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to update project", error: String(error) });
    }
  });

  app.delete("/api/projects/:id", requireAuth, async (req, res) => {
    try {
      const project = await projectsRepository.remove(req.params.id);
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project", error: String(error) });
    }
  });

  app.post("/api/projects/:id/generate", requireAuth, async (req, res) => {
    try {
      if (!req.user?.id) {
        res.status(401).json({ message: "Unauthorized" });
        return;
      }

      const projectId = req.params.id;
      const { versionId } = req.body as { versionId?: string };

      if (!versionId) {
        res.status(400).json({ message: "versionId is required" });
        return;
      }

      const project = await projectsRepository.findById(projectId);
      const version = await projectVersionsRepository.findById(versionId);

      if (!project || !version) {
        res.status(404).json({ message: "Project or version not found" });
        return;
      }

      const job = await generationJobsRepository.create({
        projectId,
        projectVersionId: versionId,
        requestedByUserId: req.user.id
      });

      await generationQueue.add("generate-app", {
        organizationId: project.organizationId,
        projectId,
        versionId,
        requestedByUserId: req.user.id,
        generationJobId: job.id
      });

      res.status(202).json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to enqueue generation job", error: String(error) });
    }
  });
}
