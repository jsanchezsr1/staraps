import { Express } from "express";
import { generationJobsRepository } from "@platform/database";
import { requireAuth } from "../../middleware/requireAuth";
import path from "path";
import fs from "fs";

export function registerJobRoutes(app: Express): void {
  app.get("/api/jobs/:jobId", requireAuth, async (req, res) => {
    try {
      const job = await generationJobsRepository.findById(req.params.jobId);
      if (!job) {
        res.status(404).json({ message: "Job not found" });
        return;
      }

      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to get job", error: String(error) });
    }
  });

  app.get("/api/jobs/:jobId/logs", requireAuth, async (req, res) => {
    try {
      const job = await generationJobsRepository.findById(req.params.jobId);
      if (!job) {
        res.status(404).json({ message: "Job not found" });
        return;
      }

      res.json({
        id: job.id,
        status: job.status,
        log: job.log ?? ""
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get job logs", error: String(error) });
    }
  });

  app.get("/api/artifacts/:artifactId/download", requireAuth, async (req, res) => {
    try {
      const artifact = await req.app.locals.prisma?.generatedArtifact?.findUnique?.({
        where: { id: req.params.artifactId }
      });

      if (!artifact) {
        res.status(404).json({ message: "Artifact not found" });
        return;
      }

      const absolutePath = path.resolve(artifact.filePath);
      if (!fs.existsSync(absolutePath)) {
        res.status(404).json({ message: "Artifact file missing" });
        return;
      }

      res.download(absolutePath, artifact.fileName);
    } catch (error) {
      res.status(500).json({ message: "Failed to download artifact", error: String(error) });
    }
  });
}
