import "dotenv/config";
import cors from "cors";
import express from "express";
import { registerAuthRoutes } from "./modules/auth/routes";
import { registerOrganizationRoutes } from "./modules/organizations/routes";
import { registerProjectRoutes } from "./modules/projects/routes";
import { registerVersionRoutes } from "./modules/versions/routes";
import { registerJobRoutes } from "./modules/jobs/routes";
import { env, logger } from "@platform/shared";
import { prisma } from "@platform/database";

const app = express();
app.locals.prisma = prisma;
app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "api-platform" });
});

registerAuthRoutes(app);
registerOrganizationRoutes(app);
registerProjectRoutes(app);
registerVersionRoutes(app);
registerJobRoutes(app);

const port = Number(env("PORT", "4000"));
app.listen(port, () => {
  logger.info(`API platform running on http://localhost:${port}`);
});
