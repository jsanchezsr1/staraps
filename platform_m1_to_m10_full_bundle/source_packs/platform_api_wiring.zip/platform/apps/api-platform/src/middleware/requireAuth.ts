import { NextFunction, Request, Response } from "express";

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }

  const token = authHeader.slice("Bearer ".length).trim();

  // Milestone 1 stub:
  // token format: demo-user:<userId>
  if (!token.startsWith("demo-user:")) {
    res.status(401).json({ message: "Invalid token format for scaffold" });
    return;
  }

  const userId = token.replace("demo-user:", "");
  if (!userId) {
    res.status(401).json({ message: "Invalid token" });
    return;
  }

  req.user = { id: userId };
  next();
}
