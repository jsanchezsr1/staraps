import "dotenv/config";
import { Worker } from "bullmq";
import IORedis from "ioredis";
import fs from "fs-extra";
import path from "path";
import { env, logger } from "@platform/shared";
import { generationJobsRepository, prisma, GenerationJobStatus, projectVersionsRepository } from "@platform/database";
import { generateApp } from "@platform/generator";
import type { GenerationJobPayload } from "./queue";

const connection = new IORedis(env("REDIS_URL", "redis://localhost:6379"), {
  maxRetriesPerRequest: null
});

const worker = new Worker<GenerationJobPayload>(
  "app-generation",
  async (job) => {
    logger.info("Processing generation job", job.id, job.data);

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.RUNNING,
      startedAt: new Date(),
      log: "Generation started"
    });

    const version = await projectVersionsRepository.findById(job.data.versionId);
    if (!version) {
      throw new Error("Project version not found");
    }

    const outputRoot = path.resolve(process.cwd(), "../../generated-apps");
    await fs.ensureDir(outputRoot);

    const result = await generateApp({
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      outputRoot,
      spec: version.appSpecJson as any
    });

    const artifactFilePath = path.join(result.baseDir, "artifact-placeholder.zip");
    await fs.writeFile(artifactFilePath, "placeholder zip content", "utf8");

    const artifact = await prisma.generatedArtifact.create({
      data: {
        generationJobId: job.data.generationJobId,
        fileName: "artifact-placeholder.zip",
        filePath: artifactFilePath
      }
    });

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.COMPLETED,
      finishedAt: new Date(),
      artifactPath: artifact.filePath,
      log: "Generation completed successfully"
    });

    return {
      ok: true,
      artifactId: artifact.id
    };
  },
  { connection }
);

worker.on("completed", (job) => {
  logger.info("Generation job completed", job?.id);
});

worker.on("failed", async (job, err) => {
  logger.error("Generation job failed", job?.id, err.message);

  if (job?.data?.generationJobId) {
    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.FAILED,
      finishedAt: new Date(),
      log: err.message
    });
  }
});

logger.info("Worker running.");
