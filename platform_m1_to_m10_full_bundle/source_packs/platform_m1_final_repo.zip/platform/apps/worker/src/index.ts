import "dotenv/config";
import { Worker } from "bullmq";
import IORedis from "ioredis";
import fs from "fs-extra";
import path from "path";
import { logger } from "@platform/shared";
import { parseEnv } from "@platform/shared/env";
import { generationJobsRepository, prisma, GenerationJobStatus, projectVersionsRepository } from "@platform/database";
import { generateApp } from "@platform/generator";

type GenerationJobPayload = {
  organizationId: string;
  projectId: string;
  versionId: string;
  requestedByUserId: string;
  generationJobId: string;
};

const validatedEnv = parseEnv(process.env);

const connection = new IORedis(validatedEnv.REDIS_URL, {
  maxRetriesPerRequest: null
});

async function setProgress(generationJobId: string, progress: number, message: string, status?: GenerationJobStatus) {
  await generationJobsRepository.updateStatus(generationJobId, {
    status: status ?? GenerationJobStatus.RUNNING,
    log: `PROGRESS:${progress} ${message}`
  });
}

const worker = new Worker<GenerationJobPayload>(
  "app-generation",
  async (job) => {
    logger.info("Processing generation job", job.id, job.data);

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.RUNNING,
      startedAt: new Date(),
      log: "PROGRESS:10 Generation started"
    });

    const version = await projectVersionsRepository.findById(job.data.versionId);
    if (!version) throw new Error("Project version not found");

    await setProgress(job.data.generationJobId, 25, "Loaded project version");

    const outputRoot = path.resolve(process.cwd(), "../../generated-apps");
    await fs.ensureDir(outputRoot);

    await setProgress(job.data.generationJobId, 50, "Preparing output directory");

    const result = await generateApp({
      projectId: job.data.projectId,
      versionId: job.data.versionId,
      outputRoot,
      spec: version.appSpecJson as any
    });

    await setProgress(job.data.generationJobId, 80, "Generated app and archived artifact");

    const stat = await fs.stat(result.zipPath);
    const checksum = await sha256File(result.zipPath);

    const artifact = await prisma.generatedArtifact.create({
      data: {
        generationJobId: job.data.generationJobId,
        fileName: path.basename(result.zipPath),
        filePath: result.zipPath,
        size: BigInt(stat.size),
        checksum
      }
    });

    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.COMPLETED,
      finishedAt: new Date(),
      artifactPath: artifact.filePath,
      log: `PROGRESS:100 Generation completed successfully. Files generated: ${result.fileCount}`
    });

    return { ok: true, artifactId: artifact.id };
  },
  { connection, concurrency: 2 }
);

worker.on("completed", (job) => logger.info("Generation job completed", job?.id));
worker.on("failed", async (job, err) => {
  logger.error("Generation job failed", job?.id, err.message);
  if (job?.data?.generationJobId) {
    await generationJobsRepository.updateStatus(job.data.generationJobId, {
      status: GenerationJobStatus.FAILED,
      finishedAt: new Date(),
      log: `PROGRESS:100 FAILED ${err.message}`
    });
  }
});

async function sha256File(filePath: string): Promise<string> {
  const crypto = await import("crypto");
  const buf = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

logger.info("Worker running.");
