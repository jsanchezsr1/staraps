export type TemplateDescriptor = {
  key: string;
  outputPath: string;
  description: string;
};

export const templateRegistry: TemplateDescriptor[] = [
  { key: "frontend/page-list", outputPath: "app/frontend/src/app/[resource]/page.tsx", description: "List page" },
  { key: "frontend/page-detail", outputPath: "app/frontend/src/app/[resource]/[id]/page.tsx", description: "Detail page" },
  { key: "frontend/page-form", outputPath: "app/frontend/src/app/[resource]/new/page.tsx", description: "Form page" },
  { key: "backend/route-crud", outputPath: "app/backend/src/routes/[resource].routes.ts", description: "CRUD route" },
  { key: "backend/controller-crud", outputPath: "app/backend/src/controllers/[resource].controller.ts", description: "CRUD controller" },
  { key: "database/prisma-model", outputPath: "app/database/prisma/schema.prisma", description: "Prisma schema" },
  { key: "admin/page-list", outputPath: "app/admin/src/app/[resource]/page.tsx", description: "Admin list page" },
  { key: "mobile/screen-list", outputPath: "app/mobile/src/screens/[resource]ListScreen.tsx", description: "Mobile list screen" }
];
