import type { AppSpec } from "@platform/app-spec";
import { prismaSchemaFromSpec } from "../utils/prismaFromSpec";

export function generatePrisma(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  return [
    { relativePath: "app/database/prisma/schema.prisma", content: prismaSchemaFromSpec(spec) },
    { relativePath: "app/database/README.md", content: "# Generated database\n\nThis folder contains the generated Prisma schema.\n" }
  ];
}
