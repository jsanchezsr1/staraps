import type { AppSpec } from "@platform/app-spec";
import { toKebabCase } from "../utils/naming";
import { listPageTemplate, formPageTemplate } from "./crudTemplates";

export function generateFrontend(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  const files: Array<{ relativePath: string; content: string }> = [
    {
      relativePath: "app/frontend/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-frontend`,
        private: true,
        scripts: { dev: "next dev", build: "next build", start: "next start" },
        dependencies: { next: "^14.2.5", react: "^18.3.1", "react-dom": "^18.3.1" }
      }, null, 2)
    },
    {
      relativePath: "app/frontend/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3000\nCMD ["npm","run","dev"]\n`
    },
    {
      relativePath: "app/frontend/src/app/page.tsx",
      content: `export default function HomePage() {\n  return <main><h1>${spec.meta.name}</h1><p>${spec.meta.description || "Generated frontend app"}</p></main>;\n}\n`
    }
  ];

  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    files.push({ relativePath: `app/frontend/src/app/${resource}/page.tsx`, content: listPageTemplate(model) });
    files.push({ relativePath: `app/frontend/src/app/${resource}/new/page.tsx`, content: formPageTemplate(model) });
  }
  return files;
}
