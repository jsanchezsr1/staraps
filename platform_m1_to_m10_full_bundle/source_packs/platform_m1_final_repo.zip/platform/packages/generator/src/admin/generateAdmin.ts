import type { AppSpec } from "@platform/app-spec";

export function generateAdmin(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  const files: Array<{ relativePath: string; content: string }> = [
    {
      relativePath: "app/admin/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-admin`,
        private: true,
        scripts: { dev: "next dev", build: "next build", start: "next start" },
        dependencies: { next: "^14.2.5", react: "^18.3.1", "react-dom": "^18.3.1" }
      }, null, 2)
    },
    {
      relativePath: "app/admin/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3002\nCMD ["npm","run","dev"]\n`
    },
    {
      relativePath: "app/admin/src/app/page.tsx",
      content: `export default function AdminHome() {\n  return <main><h1>${spec.meta.name} Admin</h1><p>Generated admin dashboard.</p></main>;\n}\n`
    }
  ];
  for (const model of spec.models) {
    files.push({
      relativePath: `app/admin/src/app/${model.name.toLowerCase()}/page.tsx`,
      content: `export default function ${model.name}AdminPage() {\n  return <main><h1>${model.name} Admin</h1><p>Manage ${model.name} records.</p></main>;\n}\n`
    });
  }
  return files;
}
