import type { AppSpec } from "@platform/app-spec";
import { toKebabCase, toPascalCase } from "../utils/naming";

export function generateBackend(spec: AppSpec): Array<{ relativePath: string; content: string }> {
  const files: Array<{ relativePath: string; content: string }> = [
    {
      relativePath: "app/backend/package.json",
      content: JSON.stringify({
        name: `${spec.meta.slug}-backend`,
        private: true,
        scripts: { dev: "tsx watch src/index.ts", build: "tsc", start: "node dist/index.js" },
        dependencies: { express: "^4.19.2", cors: "^2.8.5", zod: "^3.23.8" }
      }, null, 2)
    },
    {
      relativePath: "app/backend/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3001\nCMD ["npm","run","dev"]\n`
    },
    {
      relativePath: "app/backend/src/index.ts",
      content: `import express from "express";\nconst app = express();\napp.use(express.json());\napp.get("/health", (_req, res) => res.json({ ok: true }));\napp.listen(3001, () => console.log("Generated backend running on 3001"));\n`
    }
  ];
  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    const pascal = toPascalCase(model.name);
    files.push({
      relativePath: `app/backend/src/routes/${resource}.routes.ts`,
      content: `import { Router } from "express";\nexport const ${resource}Router = Router();\n${resource}Router.get("/", (_req, res) => res.json([]));\n${resource}Router.get("/:id", (_req, res) => res.json({ id: "1" }));\n${resource}Router.post("/", (_req, res) => res.status(201).json({ message: "Create ${pascal}" }));\n${resource}Router.patch("/:id", (_req, res) => res.json({ message: "Update ${pascal}" }));\n${resource}Router.delete("/:id", (_req, res) => res.status(204).send());\n`
    });
  }
  return files;
}
