-- Bootstrap migration placeholder.
-- Replace with the generated SQL from your actual schema migration.
SELECT 1;
