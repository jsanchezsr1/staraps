export function generatedDockerCompose() {
  return `services:
  frontend:
    build: ./app/frontend
    ports:
      - "3000:3000"
  backend:
    build: ./app/backend
    ports:
      - "3001:3001"
  admin:
    build: ./app/admin
    ports:
      - "3002:3002"
`;
}
