import { toKebabCase } from "../utils/naming";
import { listPageTemplate, formPageTemplate } from "./crudTemplates";

export function generateFrontend(spec) {
  const files = [
    {
      relativePath: "app/frontend/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3000\nCMD ["npm","run","dev"]\n`
    }
  ];
  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    files.push({ relativePath: `app/frontend/src/app/${resource}/page.tsx`, content: listPageTemplate(model) });
    files.push({ relativePath: `app/frontend/src/app/${resource}/new/page.tsx`, content: formPageTemplate(model) });
  }
  return files;
}
