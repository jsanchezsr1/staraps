export function generateAdmin(spec) {
  const files = [
    {
      relativePath: "app/admin/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3002\nCMD ["npm","run","dev"]\n`
    }
  ];
  for (const model of spec.models) {
    files.push({
      relativePath: `app/admin/src/app/${model.name.toLowerCase()}/page.tsx`,
      content: `export default function ${model.name}AdminPage() {\n  return <main><h1>${model.name} Admin</h1><p>Manage ${model.name} records.</p></main>;\n}\n`
    });
  }
  return files;
}
