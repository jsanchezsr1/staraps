import { toKebabCase, toPascalCase } from "../utils/naming";

export function generateBackend(spec) {
  const files = [
    {
      relativePath: "app/backend/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nEXPOSE 3001\nCMD ["npm","run","dev"]\n`
    }
  ];
  for (const model of spec.models) {
    const resource = toKebabCase(model.name);
    const pascal = toPascalCase(model.name);
    files.push({
      relativePath: `app/backend/src/routes/${resource}.routes.ts`,
      content: `import { Router } from "express";\nexport const ${resource}Router = Router();\n${resource}Router.get("/", (_req, res) => res.json([]));\n${resource}Router.get("/:id", (_req, res) => res.json({ id: "1" }));\n${resource}Router.post("/", (_req, res) => res.status(201).json({ message: "Create ${pascal}" }));\n${resource}Router.patch("/:id", (_req, res) => res.json({ message: "Update ${pascal}" }));\n${resource}Router.delete("/:id", (_req, res) => res.status(204).send());\n`
    });
  }
  return files;
}
