export function generateMobile(spec) {
  const files = [
    {
      relativePath: "app/mobile/Dockerfile",
      content: `FROM node:20-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nCMD ["npm","run","start"]\n`
    }
  ];
  for (const model of spec.models) {
    files.push({
      relativePath: `app/mobile/src/screens/${model.name}ListScreen.tsx`,
      content: `export function ${model.name}ListScreen() {\n  return null;\n}\n`
    });
  }
  return files;
}
